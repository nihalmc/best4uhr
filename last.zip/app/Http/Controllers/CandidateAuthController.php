<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Models\Candidate;
use App\Models\Jobs;
use App\Models\JobApplication;

class CandidateAuthController extends Controller
{
    public function index()
    {
        $candidate = Auth::guard('candidate')->user();
        $jobs = Jobs::all();
        // Fetch applied jobs for the candidate
        $appliedJobs = JobApplication::where('candidate_id', $candidate->id)
            ->with('job') // Eager load the job details
            ->get();

        return view('candidate.index', compact('candidate', 'jobs', 'appliedJobs'));
    }

    public function showLoginForm()
    {
        return redirect()->route('home');
    }

    // Handle candidate login
    public function login(Request $request)
    {
        // Validate the login data
        $request->validate([
            'username' => 'required|string',
            'password' => 'required|string',
        ], [
            'password.required' => 'The password field is required.',
        ]);

        // Attempt to log in the candidate
        if (Auth::guard('candidate')->attempt($request->only('username', 'password'))) {
            $candidate = Auth::guard('candidate')->user();

            // Authentication passed, redirect to candidate dashboard or desired page
            return redirect()->route('candidate.index')->with('success', 'Login successful.');
        }

        // Authentication failed, redirect back with errors
        return redirect()->route('home')->with('error', 'Invalid credentials.');
    }

    // Logout the candidate
    public function logout()
    {
        Auth::guard('candidate')->logout();
        return redirect()->route('home')->with('success', 'Logged out successfully.');
    }

    public function showRegistrationForm()
    {
        return redirect()->route('home');
    }

    // Store a newly created employer in the database
    public function register(Request $request)
    {
        // Validate the form data
        $request->validate([
            'name' => 'required|string|max:255',
            'contact_email' => 'required|email|unique:candidates,contact_email',
            'mobile' => 'nullable|string',
            'username' => 'required|string|unique:candidates,username',
            'password' => 'required|min:8',
        ]);

        $candidates = new Candidate();
        $candidates->name = $request->name;
        $candidates->contact_email = $request->contact_email;
        $candidates->mobile = $request->mobile;
        $candidates->username = $request->username;
        $candidates->isCandidates = true;
        $candidates->password = Hash::make($request->password);
        $candidates->save();

        // Authenticate the newly registered candidate (optional)
        Auth::guard('candidate')->login($candidates);

        return redirect()->route('candidate.index')->with('success', 'Candidate created successfully.');
    }

    public function showChangePasswordForm()
    {
        $candidate = Auth::guard('candidate')->user();
        return view('candidate.changepassword', compact('candidate'));
    }

    public function changePassword(Request $request)
    {
        // Validate the form data
        $request->validate([
            'old_password' => 'required',
            'new_password' => 'required|string|min:8|confirmed',
        ]);

        // Check if the old password matches the current authenticated candidate's password
        $user = Auth::guard('candidate')->user();
        if (!Hash::check($request->old_password, $user->password)) {
            return redirect()->route('candidate.change.password')->with('error', 'The provided old password is incorrect.');
        }

        // Update the employer's password
        $user->password = Hash::make($request->new_password);
        $user->save();

        return redirect()->route('candidate.change.password')->with('success', 'Password changed successfully.');
    }
}
