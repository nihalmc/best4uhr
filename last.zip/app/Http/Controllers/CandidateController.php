<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Models\Candidate;

class CandidateController extends Controller
{
public function index(Request $request)
{
    // Get all candidates by default, ordered by 'created_at' in descending order
    $candidates = Candidate::orderBy('created_at', 'desc')->get();

    // Get the selected candidate IDs from the request
    $selectedIds = $request->input('selected_ids', []);

    // If selected IDs are provided, filter the candidates
    if (!empty($selectedIds)) {
        $candidates = Candidate::whereIn('id', $selectedIds)->orderBy('created_at', 'desc')->get();
    }

    return view('admin.candidate.index', [
        'candidates' => $candidates,
        'selectedIds' => $selectedIds,
    ]);
}



    // Show the form for creating a new employer
    public function create()
    {
        return view('admin.candidate.create');
    }

    // Store a newly created employer in the database
    public function store(Request $request)
    {
        // Validate the form data
        $request->validate([  // image title order_number title2 link
        'name' => 'required|string|max:255',
        'contact_email' => 'required|email|unique:candidates,contact_email',
        'mobile' => 'nullable|string',
        'username' => 'required|string|unique:candidates,username',
        'password' => 'required|min:8',

        ]);


        $candidates = new Candidate();
        $candidates->name=$request->name;
        $candidates->contact_email=$request->contact_email;
        $candidates->mobile = $request->mobile;
        $candidates->username=$request->username;
        $candidates->isCandidates = true;
        $candidates->password = Hash::make($request->password);

        $candidates->save();


        return redirect()->route('candidates.index')->with('success', 'Candidate created successfully');
    }

    // Show the form for editing an employer
    public function edit($id)
    {
        $candidates = Candidate::findOrFail($id); // Find the employer by ID
        return view('admin.candidate.edit', ['candidates' => $candidates]);
    }

    // Update the specified employer in the database
    public function update(Request $request, $id)
    {

         $request->validate([
            'name' => 'required|string|max:255',
            'contact_email' => 'required|email|unique:candidates,contact_email,' . $id,
            'username' => 'required|string|unique:candidates,username,' . $id,
            'mobile' => 'nullable|string',
            'password' => 'nullable|min:8',
        ]);

        // Find the employer by ID
        $candidates = Candidate::findOrFail($id);

        // Update the employer's information
        $candidates->name = $request->name;
        $candidates->contact_email = $request->contact_email;
        $candidates->mobile = $request->mobile;
        $candidates->username = $request->username;
        $candidates->password = Hash::make($request->password);

        $candidates->save();

        return redirect()->route('candidates.index')->with('success', 'Candidate updated successfully');
    }

    // Remove the specified employer from the database
    public function destroy($id)
    {
        $candidates = Candidate::findOrFail($id);
        $candidates->delete();

        return redirect()->route('candidates.index')->with('success', 'Candidate deleted successfully');
    }



}
