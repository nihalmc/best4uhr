<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Hash;

use Illuminate\Http\Request;
use App\Models\Employers;

class EmployerController extends Controller
{
    public function index()
{
    $employers = Employers::orderBy('created_at', 'desc')->get(); // Fetch all employers from the database, ordered by 'created_at' in descending order
    return view('admin.employers.index', ['employers' => $employers]);
}


    // Show the form for creating a new employer
    public function create()
    {
        return view('admin.employers.create');
    }

    // Store a newly created employer in the database
    public function store(Request $request)
    {
        // Validate the form data
        $request->validate([  // image title order_number title2 link
        'company_name' => 'required|string|max:255',
        'contact_email' => 'required|email|unique:employers,contact_email',
        'mobile' => 'nullable|string',
        'username' => 'required|string|unique:employers,username',
        'password' => 'required|min:8',

        ]);


        $employers = new Employers();
        $employers->company_name=$request->company_name;
        $employers->contact_email=$request->contact_email;
       $employers->mobile = $request->mobile;
        $employers->username=$request->username;
        $employers->isEmployer = true;
        $employers->password = Hash::make($request->password);



        $employers->save();


        return redirect()->route('employers.index')->with('success', 'Employer created successfully');
    }

    // Show the form for editing an employer
    public function edit($id)
    {
        $employers = Employers::findOrFail($id); // Find the employer by ID
        return view('admin.employers.edit', ['employers' => $employers]);
    }

    // Update the specified employer in the database
    public function update(Request $request, $id)
    {

         $request->validate([
            'company_name' => 'required|string|max:255',
            'contact_email' => 'required|email|unique:employers,contact_email,' . $id,
            'mobile' => 'nullable|string',
            'username' => 'required|string|unique:employers,username,' . $id,
            'password' => 'nullable|min:6',
        ]);

        // Find the employer by ID
        $employers = Employers::findOrFail($id);

        // Update the employer's information
        $employers->company_name = $request->company_name;
        $employers->contact_email = $request->contact_email;
        $employers->mobile = $request->mobile;
        $employers->username = $request->username;
        $employers->password = Hash::make($request->password);

        $employers->save();

        return redirect()->route('employers.index')->with('success', 'Employer updated successfully');
    }

    // Remove the specified employer from the database
    public function destroy($id)
    {
         try {
        $employer = Employers::findOrFail($id);
        $employer->delete();

        return redirect()->route('employers.index')->with('success', 'Employer deleted successfully');
         } catch (\Exception $e) {
        // Handle any exceptions that occur during the deletion process
        // You can log the error for debugging purposes
        // Log::error($e->getMessage());

        // Redirect back with an error message
        return redirect()->back()->with('error', 'Cannot delete  the employer because related jobs exist.');
    }
    }
}
