<?php $__env->startSection('content'); ?>

        <!-- Page Content Holder -->
        <div id="content">

            <div class="content-admin-main">

                <div class="wt-admin-right-page-header clearfix">
                    <h2>Cv Inbox</h2>
                    <div class="breadcrumbs"><a href="#">Home</a><a href="#">Dasboard</a><span>Cv Inbox</span></div>
                </div>
                <div class="twm-pro-view-chart-wrap">

                    <div class="col-lg-12 col-md-12 mb-4">
                        <div class="panel panel-default site-bg-white m-t30">
                            <div class="panel-heading wt-panel-heading p-a20">
                                <h4 class="panel-tittle m-a0"><i class="far fa-list-alt"></i>Cv Inbox</h4>

                            </div>

                            <div class="panel-body wt-panel-body">
                                <div class="twm-D_table p-a20 table-responsive">
                                    <table id="candidate_data_table" class="table table-bordered">
                                        <thead>
                                            <tr>

                                                <th>Name</th>
                                                 <th>Email</th>
                                                 <th>Mobile</th>
                                                 <th>Job position</th>

                                               <th>Resume</th>

                                            </tr>
                                        </thead>
                                        <tbody>
                                            <!--1-->
                                            <?php $__currentLoopData = $cvenquiry; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>

                                                <td>
                                                    <div class="twm-DT-candidates-list">

                                                        <div class="twm-mid-content">
                                                            <a href="#" class="twm-job-title">
                                                                <h4><?php echo e($employer->name); ?> </h4>

                                                            </a>

                                                        </div>

                                                    </div>
                                                </td>
                                                <td><?php echo e($employer->email); ?></td>
                                                <td><?php echo e($employer->mobile); ?></td>
                                                <td><?php echo e($employer->job_position); ?></td>
                      <td>
                        <iframe src="<?php echo e(asset('storage/' . $employer->resume)); ?>" width="150px"></iframe>
                        <a href="<?php echo e(asset('storage/' . $employer->resume)); ?>" target="_blank"><span class="fa fa-eye"></span></a>
                    </td>
                                            </tr>
 </tbody> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>




            </div>

    	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nihal/Desktop/laravel/best4uhr/resources/views/admin/cvenquiry.blade.php ENDPATH**/ ?>