<!DOCTYPE html>
<html>
<head>
    <title>Contact Form Submission</title>
</head>
<body>
    <h2>Contact Form Submission</h2>
    <p><strong>Name:</strong> <?php echo e($data['username']); ?></p>
    <p><strong>Email:</strong> <?php echo e($data['email']); ?></p>
    <p><strong>Phone:</strong> <?php echo e($data['phone']); ?></p>
    <p><strong>Subject:</strong> <?php echo e($data['subject'] ?? 'N/A'); ?></p>
    <p><strong>Message:</strong> <?php echo e($data['message']); ?></p>
</body>
</html>
<?php /**PATH /home/nihal/Desktop/laravel/best4uhr/resources/views/emails/contact.blade.php ENDPATH**/ ?>