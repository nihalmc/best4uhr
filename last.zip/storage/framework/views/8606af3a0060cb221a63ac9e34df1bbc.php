<?php $__env->startSection('content'); ?>
    <!-- Page Content Holder -->
    <div id="content">
        <div class="content-admin-main">
            <div class="wt-admin-right-page-header clearfix">
                <h2>Applied Jobs</h2>
                <div class="breadcrumbs">
                    <a href="#">Home</a>
                    <a href="#">Dashboard</a>
                    <span>Applied Jobs</span>
                </div>
            </div>
            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <div class="twm-pro-view-chart-wrap">
                <div class="col-lg-12 col-md-12 mb-4">
                    <div class="panel panel-default site-bg-white m-t30">
                        <div class="panel-heading wt-panel-heading p-a20">
                            <h4 class="panel-tittle m-a0"><i class="far fa-list-alt"></i> Applied Jobs</h4>
                        </div>
                        <div class="panel-body wt-panel-body p-a20 m-b30">
                            <div class="twm-D_table p-a20 table-responsive">
                                <table id="jobs_bookmark_table" class="table table-bordered twm-bookmark-list-wrap">
                                    <thead>
                                        <tr>
                                            <th>Job code</th>
                                            <th>Name</th>
                                            <th>Applied for</th>
                                            <th>Email</th>
                                            <th>Mobile</th>
                                            <th>Date</th>
                                            <th>Resume</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $appliedJobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($application->job->job_code); ?></td>
                                                <td>
                                                    <div class="twm-bookmark-list">
                                                        <div class="twm-mid-content">
                                                            <a href="#" class="twm-job-title"><?php echo e($application->candidate->name); ?></a>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td><?php echo e($application->job->job_position); ?></td>
                                                <td><?php echo e($application->candidate->contact_email); ?></td>
                                                <td><?php echo e($application->candidate->mobile); ?></td>
                                                <td><?php echo e(date('d/m/Y', strtotime($application->created_at))); ?></td>
                                                <td>
                                                    <?php if($application->resume): ?>
                                                        <iframe src="<?php echo e(asset('storage/' . $application->resume)); ?>"
                                                            width="150px"></iframe>
                                                        <a href="<?php echo e(asset('storage/' . $application->resume)); ?>" target="_blank">
                                                            <span class="fa fa-eye"></span>
                                                        </a>
                                                    <?php else: ?>
                                                        No Resume Attached
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <div class="twm-table-controls">
                                                        <ul class="twm-DT-controls-icon list-unstyled">
                                                            <li>
                                                                <button title="View more details" data-bs-toggle="tooltip"
                                                                    data-bs-placement="top">
                                                                    <a data-bs-toggle="modal" href="#applicationModal<?php echo e($application->id); ?>"
                                                                        role="button">
                                                                        <span class="far fa-eye"></span>
                                                                    </a>
                                                                </button>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

  <?php $__currentLoopData = $appliedJobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <!-- Modal for Application Details -->
    <div class="modal fade twm-saved-jobs-view" id="applicationModal<?php echo e($application->id); ?>" tabindex="-1" role="dialog" aria-labelledby="applicationModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <form>

                    <div class="modal-header">
                        <h2 class="modal-title">Application Details</h2>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>

                    <div class="modal-body">

                        <div class="row">
                            <div class="col-xl-12 col-lg-12">
                                <div class="form-group">
                                    <label>Name:</label>
                                    <div class="ls-inputicon-box">
                                        <input class="form-control" type="text"  value="<?php echo e($application->candidate->name); ?>">

                                    </div>
                                </div>
                            </div>
                          <div class="col-xl-12 col-lg-12">
                                <div class="form-group">
                                    <label>Applied for:</label>
                                    <div class="ls-inputicon-box">
                                        <input class="form-control" type="text" value="<?php echo e($application->job->job_position); ?>">

                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-12 col-lg-12">
                                <div class="form-group">
                                    <label>Email:</label>
                                    <div class="ls-inputicon-box">
                                        <input class="form-control" type="text" value="<?php echo e($application->candidate->contact_email); ?>" >

                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-12 col-lg-12">
                                <div class="form-group">
                                    <label>Mobile:</label>
                                    <div class="ls-inputicon-box">
                                        <input class="form-control" type="text" value="<?php echo e($application->candidate->mobile); ?>">

                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-12 col-lg-12">
                                <div class="form-group">
                                    <label>Date:</label>
                                    <div class="ls-inputicon-box">
                                        <input class="form-control" type="text" value=" <?php echo e(date('d/m/Y', strtotime($application->created_at))); ?>">

                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-12 col-lg-12">
                                <div class="form-group">
                                    <label>Home Country:</label>
                                    <div class="ls-inputicon-box">
                                        <input class="form-control" type="text" value="<?php echo e($application->candidate->candidateDetail->home_country); ?>">

                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-12 col-lg-12">
                                <div class="form-group">
                                    <label>Nationality:</label>
                                    <div class="ls-inputicon-box">
                                        <input class="form-control" type="text" value="<?php echo e($application->candidate->candidateDetail->nationality); ?>">

                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-12 col-lg-12">
                                <div class="form-group">
                                    <label>Experience Regions</label>
                                    <div class="ls-inputicon-box">
                                        <input class="form-control" type="text" value="<?php echo e($application->candidate->candidateDetail->experience_region); ?>">
                                              <label>Experience in Years</label>
                                               <input class="form-control" type="text" value="<?php echo e($application->candidate->candidateDetail->experience_years); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-12 col-lg-12">
                                <div class="form-group">
                                    <label>Language Known</label>
                                    <div class="ls-inputicon-box">
                                        <input class="form-control" type="text" value="<?php echo e($application->candidate->candidateDetail->languages_known); ?>">

                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-12 col-lg-12">
                                <div class="form-group">
                                    <label>Qualification</label>
                                    <div class="ls-inputicon-box">
                                        <input class="form-control" type="text" value="<?php echo e($application->candidate->candidateDetail->qualification); ?>">

                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-12 col-lg-12">
                                <div class="form-group">
                                    <label>Do you have a UAE driving license?</label>
                                    <div class="ls-inputicon-box">
                                     <input class="form-control" type="text" value="<?php echo e($application->candidate->candidateDetail->driving_licence); ?>">
                                     <label>UAE driving license Expiry Date</label>
                                     <input class="form-control" type="text" value="<?php echo e($application->candidate->candidateDetail->driving_licence_expiry_date); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-12 col-lg-12">
                                <div class="form-group">
                                    <label>Resume:</label>
                                    <div class="ls-inputicon-box">
                                        <?php if($application->resume): ?>
                                <a href="<?php echo e(asset('storage/' . $application->resume)); ?>" target="_blank">View Resume</a>
                            <?php else: ?>
                                No Resume Attached
                            <?php endif; ?>

                                    </div>
                                </div>
                            </div>
 <div class="modal-footer">

                                                            <button type="button" class="site-button" data-bs-dismiss="modal">Close</button>


                                                        </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nihal/Desktop/laravel/best4uhr/resources/views/admin/candidate/show.blade.php ENDPATH**/ ?>