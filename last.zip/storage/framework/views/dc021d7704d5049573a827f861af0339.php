<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Job Details</h2>

    <div class="card">
        <div class="card-body">
            <h4 class="card-title"><?php echo e($job->job_position); ?></h4>

            <p class="card-text">
                <strong>Field of Work:</strong> <?php echo e($job->field_of_work); ?><br>
                <strong>Location:</strong> <?php echo e($job->location); ?><br>
                <strong>Salary:</strong> <?php echo e($job->salary); ?><br>
                <strong>Nationality:</strong> <?php echo e($job->nationality); ?><br>
                <strong>Gender:</strong> <?php echo e($job->gender); ?><br>
                <strong>Requirements:</strong><br><?php echo e($job->requirements); ?><br>
                <strong>Posted Date:</strong> <?php echo e($job->posted_date); ?><br>
                <strong>Closing Date:</strong> <?php echo e($job->closing_date); ?><br>
                <!-- Add more job attributes as needed -->
            </p>
        </div>
    </div>

    <!-- Add a link to go back to the job listings -->
    <a href="<?php echo e(route('jobs.index')); ?>" class="btn btn-secondary">Back to Job Listings</a>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nihal/Desktop/laravel/best4uhr/resources/views/admin/jobs/show.blade.php ENDPATH**/ ?>