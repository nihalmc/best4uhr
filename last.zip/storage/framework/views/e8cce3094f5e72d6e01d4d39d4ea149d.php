<?php $__env->startSection('content'); ?>
<!-- CONTENT START -->
        <div class="page-content">

            <!-- INNER PAGE BANNER -->
            <div class="wt-bnr-inr overlay-wraper bg-center" style="background-image:url(images/banner/1.jpg);">
                <div class="overlay-main site-bg-white opacity-01"></div>
                <div class="container">
                    <div class="wt-bnr-inr-entry">
                        <div class="banner-title-outer">
                            <div class="banner-title-name">
                                <h2 class="wt-title">Job Seeker Profile</h2>
                            </div>
                        </div>
                        <!-- BREADCRUMB ROW -->

                            <div>
                                <ul class="wt-breadcrumb breadcrumb-style-2">
                                    <li><a href="<?php echo e(route('candidate.index')); ?>">Home</a></li>
                                    <li>Job Seeker Profile</li>
                                </ul>
                            </div>

                        <!-- BREADCRUMB ROW END -->
                    </div>
                </div>
            </div>
            <!-- INNER PAGE BANNER END -->


            <!-- OUR BLOG START -->
            <div class="section-full p-t60  p-b90 site-bg-white">


                <div class="container">
                    <div class="row">

                        <div class="col-xl-3 col-lg-4 col-md-12 rightSidebar m-b30">

                            <div class="side-bar-st-1">


                                <div class="twm-mid-content text-center">
                                    <a href="candidate-detail.html" class="twm-job-title">
                                        <h4><?php echo e($candidate->name); ?>  </h4>
                                    </a>

                                </div>

                                <div class="twm-nav-list-1">
                                    <ul>
                                        <li class="active"><a href="<?php echo e(route('candidate.index')); ?>"><i class="fa fa-tachometer-alt"></i> Dashboard</a></li>
                                        <li><a href="<?php echo e(route('candidate-details.create')); ?>"><i class="fa fa-user"></i> My Profile</a></li>
                                        <li><a href="<?php echo e(route('candidate.applied-jobs')); ?>"><i class="fa fa-suitcase"></i> Applied Jobs</a></li>
                                        <li><a href="<?php echo e(route('candidate.jobs.index')); ?>"><i class="fa fa-bell"></i> Job Alerts</a></li>
                                        <li><a href="<?php echo e(route('candidate.change.password.form')); ?>"><i class="fa fa-fingerprint"></i> Change Password</a></li>
                                        <li><a href="javascript:;" data-bs-toggle="modal" data-bs-target="#logout-dash-profile"><i class="fa fa-share-square"></i>Logout</a></li>

                                    </ul>
                                </div>

                            </div>

                        </div>

                        <div class="col-xl-9 col-lg-8 col-md-12 m-b30">
                            <!--Filter Short By-->
                             <?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
                            <div class="twm-right-section-panel site-bg-gray">
                                <form method="POST" action="<?php echo e(route('candidate.details.update')); ?>" enctype="multipart/form-data">

  <?php echo csrf_field(); ?>
   <?php echo method_field('PUT'); ?>

                                    <!--Basic Information-->
                                    <div class="panel panel-default">
                                        <div class="panel-heading wt-panel-heading p-a20">
                                            <h4 class="panel-tittle m-a0">Basic Informations</h4>
                                        </div>
                                        <div class="panel-body wt-panel-body p-a20 m-b30 ">

                                            <div class="row">

<div class="col-xl-6 col-lg-6 col-md-12">
                                                        <div class="form-group city-outer-bx has-feedback">
                                                            <label>Your Name</label>
                                                            <div class="ls-inputicon-box">
                                                                <input class="form-control" name="name" value="<?php echo e(old('name', $candidate->name)); ?>" type="text" placeholder="Your Name">
                                                                <i class="fs-input-icon fa fa-user "></i>
                                                                <?php if($errors->has('name')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-xl-6 col-lg-6 col-md-12">
                                                        <div class="form-group city-outer-bx has-feedback">
                                                            <label>Phone</label>
                                                            <div class="ls-inputicon-box">
                                                                <input class="form-control" name="mobile" id="mobile" type="text" value="<?php echo e($candidate->mobile); ?>" placeholder="Your Phone">
                                                                <i class="fs-input-icon fa fa-phone-alt"></i>
  <?php if($errors->has('mobile')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('mobile')); ?></span>
                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-xl-4 col-lg-6 col-md-12">
                                                        <div class="form-group city-outer-bx has-feedback">
                                                            <label>Email Address</label>
                                                            <div class="ls-inputicon-box">
                                                                <input class="form-control" name="contact_email" value="<?php echo e(old('contact_email', $candidate->contact_email)); ?>" type="email" placeholder="Your Email Address">
                                                                <i class="fs-input-icon fas fa-at"></i>
                                                                <?php if($errors->has('contact_email')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('contact_email')); ?></span>
                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                             <div class="col-xl-4 col-lg-6 col-md-12">
                                                        <div class="form-group city-outer-bx has-feedback">
                                                            <label>Home Country</label>
                                                            <div class="ls-inputicon-box">
                                                                <input class="form-control" name="home_country" value="<?php echo e(old('home_country', $candidateDetail->home_country ?? '')); ?>" type="text" placeholder="UAE">
                                                                <i class="fs-input-icon fa fa-globe-americas"></i>
                                                            </div>
<?php if($errors->has('home_country')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('home_country')); ?></span>
                                <?php endif; ?>
                                                        </div>
                                                    </div>



                                                    <div class="col-xl-4 col-lg-6 col-md-12">
                                                        <div class="form-group city-outer-bx has-feedback">
                                                            <label>Nationality</label>
                                                            <div class="ls-inputicon-box">
<select class="wt-select-box selectpicker" id="nationality" name="nationality" data-live-search="true" title="" id="country" data-bv-field="size">
                                                    <option class="bs-title-option" value="">Nationality</option>
                                                     <option value="Afghanistan" <?php echo e($candidate->candidateDetail->nationality === 'Afghanistan' ? 'selected' : ''); ?>>Afghanistan</option>
    <option value="Albania" <?php echo e($candidate->candidateDetail->nationality === 'Albania' ? 'selected' : ''); ?>>Albania</option>
    <option value="Algeria" <?php echo e($candidate->candidateDetail->nationality === 'Algeria' ? 'selected' : ''); ?>>Algeria</option>
    <option value="American Samoa" <?php echo e($candidate->candidateDetail->nationality === 'American Samoa' ? 'selected' : ''); ?>>American Samoa</option>
    <option value="Andorra" <?php echo e($candidate->candidateDetail->nationality === 'Andorra' ? 'selected' : ''); ?>>Andorra</option>
    <option value="Angola" <?php echo e($candidate->candidateDetail->nationality === 'Angola' ? 'selected' : ''); ?>>Angola</option>
    <option value="Anguilla" <?php echo e($candidate->candidateDetail->nationality === 'Anguilla' ? 'selected' : ''); ?>>Anguilla</option>
    <option value="Antarctica" <?php echo e($candidate->candidateDetail->nationality === 'Antarctica' ? 'selected' : ''); ?>>Antarctica</option>
    <option value="Antigua and Barbuda" <?php echo e($candidate->candidateDetail->nationality === 'Antigua and Barbuda' ? 'selected' : ''); ?>>Antigua and Barbuda</option>
    <option value="Argentina" <?php echo e($candidate->candidateDetail->nationality === 'Argentina' ? 'selected' : ''); ?>>Argentina</option>
    <option value="Armenia" <?php echo e($candidate->candidateDetail->nationality === 'Armenia' ? 'selected' : ''); ?>>Armenia</option>
    <option value="Aruba" <?php echo e($candidate->candidateDetail->nationality === 'Aruba' ? 'selected' : ''); ?>>Aruba</option>
    <option value="Australia" <?php echo e($candidate->candidateDetail->nationality === 'Australia' ? 'selected' : ''); ?>>Australia</option>
    <option value="Austria" <?php echo e($candidate->candidateDetail->nationality === 'Austria' ? 'selected' : ''); ?>>Austria</option>
    <option value="Azerbaijan" <?php echo e($candidate->candidateDetail->nationality === 'Azerbaijan' ? 'selected' : ''); ?>>Azerbaijan</option>
    <option value="Bahamas" <?php echo e($candidate->candidateDetail->nationality === 'Bahamas' ? 'selected' : ''); ?>>Bahamas</option>
    <option value="Bahrain" <?php echo e($candidate->candidateDetail->nationality === 'Bahrain' ? 'selected' : ''); ?>>Bahrain</option>
    <option value="Bangladesh" <?php echo e($candidate->candidateDetail->nationality === 'Bangladesh' ? 'selected' : ''); ?>>Bangladesh</option>
    <option value="Barbados" <?php echo e($candidate->candidateDetail->nationality === 'Barbados' ? 'selected' : ''); ?>>Barbados</option>
    <option value="Belarus" <?php echo e($candidate->candidateDetail->nationality === 'Belarus' ? 'selected' : ''); ?>>Belarus</option>
    <option value="Belgium" <?php echo e($candidate->candidateDetail->nationality === 'Belgium' ? 'selected' : ''); ?>>Belgium</option>
    <option value="Belize" <?php echo e($candidate->candidateDetail->nationality === 'Belize' ? 'selected' : ''); ?>>Belize</option>
    <option value="Benin" <?php echo e($candidate->candidateDetail->nationality === 'Benin' ? 'selected' : ''); ?>>Benin</option>
    <option value="Bermuda" <?php echo e($candidate->candidateDetail->nationality === 'Bermuda' ? 'selected' : ''); ?>>Bermuda</option>
    <option value="Bhutan" <?php echo e($candidate->candidateDetail->nationality === 'Bhutan' ? 'selected' : ''); ?>>Bhutan</option>
    <option value="Bolivia" <?php echo e($candidate->candidateDetail->nationality === 'Bolivia' ? 'selected' : ''); ?>>Bolivia</option>
    <option value="Bosnia and Herzegovina" <?php echo e($candidate->candidateDetail->nationality === 'Bosnia and Herzegovina' ? 'selected' : ''); ?>>Bosnia and Herzegovina</option>
    <option value="Botswana" <?php echo e($candidate->candidateDetail->nationality === 'Botswana' ? 'selected' : ''); ?>>Botswana</option>
    <option value="Bouvet Island" <?php echo e($candidate->candidateDetail->nationality === 'Bouvet Island' ? 'selected' : ''); ?>>Bouvet Island</option>
    <option value="Brazil" <?php echo e($candidate->candidateDetail->nationality === 'Brazil' ? 'selected' : ''); ?>>Brazil</option>
    <option value="British Indian Ocean Territory" <?php echo e($candidate->candidateDetail->nationality === 'British Indian Ocean Territory' ? 'selected' : ''); ?>>British Indian Ocean Territory</option>
    <option value="Brunei Darussalam" <?php echo e($candidate->candidateDetail->nationality === 'Brunei Darussalam' ? 'selected' : ''); ?>>Brunei Darussalam</option>
    <option value="Bulgaria" <?php echo e($candidate->candidateDetail->nationality === 'Bulgaria' ? 'selected' : ''); ?>>Bulgaria</option>
    <option value="Burkina Faso" <?php echo e($candidate->candidateDetail->nationality === 'Burkina Faso' ? 'selected' : ''); ?>>Burkina Faso</option>
    <option value="Burundi" <?php echo e($candidate->candidateDetail->nationality === 'Burundi' ? 'selected' : ''); ?>>Burundi</option>
    <option value="Cambodia" <?php echo e($candidate->candidateDetail->nationality === 'Cambodia' ? 'selected' : ''); ?>>Cambodia</option>
    <option value="Cameroon" <?php echo e($candidate->candidateDetail->nationality === 'Cameroon' ? 'selected' : ''); ?>>Cameroon</option>
    <option value="Canada" <?php echo e($candidate->candidateDetail->nationality === 'Canada' ? 'selected' : ''); ?>>Canada</option>
    <option value="Cape Verde" <?php echo e($candidate->candidateDetail->nationality === 'Cape Verde' ? 'selected' : ''); ?>>Cape Verde</option>
    <option value="Cayman Islands" <?php echo e($candidate->candidateDetail->nationality === 'Cayman Islands' ? 'selected' : ''); ?>>Cayman Islands</option>
    <option value="Central African Republic" <?php echo e($candidate->candidateDetail->nationality === 'Central African Republic' ? 'selected' : ''); ?>>Central African Republic</option>
    <option value="Chad" <?php echo e($candidate->candidateDetail->nationality === 'Chad' ? 'selected' : ''); ?>>Chad</option>
    <option value="Chile" <?php echo e($candidate->candidateDetail->nationality === 'Chile' ? 'selected' : ''); ?>>Chile</option>
    <option value="China" <?php echo e($candidate->candidateDetail->nationality === 'China' ? 'selected' : ''); ?>>China</option>
    <option value="Christmas Island" <?php echo e($candidate->candidateDetail->nationality === 'Christmas Island' ? 'selected' : ''); ?>>Christmas Island</option>
    <option value="Cocos Islands" <?php echo e($candidate->candidateDetail->nationality === 'Cocos Islands' ? 'selected' : ''); ?>>Cocos (Keeling) Islands</option>
    <option value="Colombia" <?php echo e($candidate->candidateDetail->nationality === 'Colombia' ? 'selected' : ''); ?>>Colombia</option>
    <option value="Comoros" <?php echo e($candidate->candidateDetail->nationality === 'Comoros' ? 'selected' : ''); ?>>Comoros</option>
    <option value="Congo" <?php echo e($candidate->candidateDetail->nationality === 'Congo' ? 'selected' : ''); ?>>Congo</option>
    <option value="Congo, the Democratic Republic of the" <?php echo e($candidate->candidateDetail->nationality === 'Congo, the Democratic Republic of the' ? 'selected' : ''); ?>>Congo, the Democratic Republic of the</option>
    <option value="Cook Islands" <?php echo e($candidate->candidateDetail->nationality === 'Cook Islands' ? 'selected' : ''); ?>>Cook Islands</option>
    <option value="Costa Rica" <?php echo e($candidate->candidateDetail->nationality === 'Costa Rica' ? 'selected' : ''); ?>>Costa Rica</option>
    <option value="Cote d'Ivoire" <?php echo e($candidate->candidateDetail->nationality === 'Cote d Ivoire' ? 'selected' : ''); ?>>Cote d'Ivoire</option>
    <option value="Croatia" <?php echo e($candidate->candidateDetail->nationality === 'Croatia' ? 'selected' : ''); ?>>Croatia (Hrvatska)</option>
    <option value="Cuba" <?php echo e($candidate->candidateDetail->nationality === 'Cuba' ? 'selected' : ''); ?>>Cuba</option>
    <option value="Cyprus" <?php echo e($candidate->candidateDetail->nationality === 'Cyprus' ? 'selected' : ''); ?>>Cyprus</option>
    <option value="Czech Republic" <?php echo e($candidate->candidateDetail->nationality === 'Czech Republic' ? 'selected' : ''); ?>>Czech Republic</option>
    <option value="Denmark" <?php echo e($candidate->candidateDetail->nationality === 'Denmark' ? 'selected' : ''); ?>>Denmark</option>
    <option value="Djibouti" <?php echo e($candidate->candidateDetail->nationality === 'Djibouti' ? 'selected' : ''); ?>>Djibouti</option>
    <option value="Dominica" <?php echo e($candidate->candidateDetail->nationality === 'Dominica' ? 'selected' : ''); ?>>Dominica</option>
    <option value="Dominican Republic" <?php echo e($candidate->candidateDetail->nationality === 'Dominican Republic' ? 'selected' : ''); ?>>Dominican Republic</option>
    <option value="East Timor" <?php echo e($candidate->candidateDetail->nationality === 'East Timor' ? 'selected' : ''); ?>>East Timor</option>
    <option value="Ecuador" <?php echo e($candidate->candidateDetail->nationality === 'Ecuador' ? 'selected' : ''); ?>>Ecuador</option>
    <option value="Egypt" <?php echo e($candidate->candidateDetail->nationality === 'Egypt' ? 'selected' : ''); ?>>Egypt</option>
    <option value="El Salvador" <?php echo e($candidate->candidateDetail->nationality === 'El Salvador' ? 'selected' : ''); ?>>El Salvador</option>
    <option value="Equatorial Guinea" <?php echo e($candidate->candidateDetail->nationality === 'Equatorial Guinea' ? 'selected' : ''); ?>>Equatorial Guinea</option>
    <option value="Eritrea" <?php echo e($candidate->candidateDetail->nationality === 'Eritrea' ? 'selected' : ''); ?>>Eritrea</option>
    <option value="Estonia" <?php echo e($candidate->candidateDetail->nationality === 'Estonia' ? 'selected' : ''); ?>>Estonia</option>
    <option value="Ethiopia" <?php echo e($candidate->candidateDetail->nationality === 'Ethiopia' ? 'selected' : ''); ?>>Ethiopia</option>
    <option value="Falkland Islands (Malvinas)" <?php echo e($candidate->candidateDetail->nationality === 'Falkland Islands (Malvinas)' ? 'selected' : ''); ?>>Falkland Islands (Malvinas)</option>
    <option value="Faroe Islands" <?php echo e($candidate->candidateDetail->nationality === 'Faroe Islands' ? 'selected' : ''); ?>>Faroe Islands</option>
    <option value="Fiji" <?php echo e($candidate->candidateDetail->nationality === 'Fiji' ? 'selected' : ''); ?>>Fiji</option>
<option value="Finland" <?php echo e($candidate->candidateDetail->nationality === 'Finland' ? 'selected' : ''); ?>>Finland</option>
<option value="France" <?php echo e($candidate->candidateDetail->nationality === 'France' ? 'selected' : ''); ?>>France</option>
<option value="Gabon" <?php echo e($candidate->candidateDetail->nationality === 'Gabon' ? 'selected' : ''); ?>>Gabon</option>
<option value="Gambia" <?php echo e($candidate->candidateDetail->nationality === 'Gambia' ? 'selected' : ''); ?>>Gambia</option>
<option value="Georgia" <?php echo e($candidate->candidateDetail->nationality === 'Georgia' ? 'selected' : ''); ?>>Georgia</option>
<option value="Germany" <?php echo e($candidate->candidateDetail->nationality === 'Germany' ? 'selected' : ''); ?>>Germany</option>
<option value="Greece" <?php echo e($candidate->candidateDetail->nationality === 'Greece' ? 'selected' : ''); ?>>Greece</option>
<option value="Greenland" <?php echo e($candidate->candidateDetail->nationality === 'Greenland' ? 'selected' : ''); ?>>Greenland</option>
<option value="Grenada" <?php echo e($candidate->candidateDetail->nationality === 'Grenada' ? 'selected' : ''); ?>>Grenada</option>
<option value="Guadeloupe" <?php echo e($candidate->candidateDetail->nationality === 'Guadeloupe' ? 'selected' : ''); ?>>Guadeloupe</option>
<option value="Guam" <?php echo e($candidate->candidateDetail->nationality === 'Guam' ? 'selected' : ''); ?>>Guam</option>
<option value="Guatemala" <?php echo e($candidate->candidateDetail->nationality === 'Guatemala' ? 'selected' : ''); ?>>Guatemala</option>
<option value="Guinea" <?php echo e($candidate->candidateDetail->nationality === 'Guinea' ? 'selected' : ''); ?>>Guinea</option>
<option value="Guinea-Bissau" <?php echo e($candidate->candidateDetail->nationality === 'Guinea-Bissau' ? 'selected' : ''); ?>>Guinea-Bissau</option>
<option value="Guyana" <?php echo e($candidate->candidateDetail->nationality === 'Guyana' ? 'selected' : ''); ?>>Guyana</option>
<option value="Haiti" <?php echo e($candidate->candidateDetail->nationality === 'Haiti' ? 'selected' : ''); ?>>Haiti</option>
<option value="Heard and McDonald Islands" <?php echo e($candidate->candidateDetail->nationality === 'Heard and McDonald Islands' ? 'selected' : ''); ?>>Heard and McDonald Islands</option>
<option value="Holy See" <?php echo e($candidate->candidateDetail->nationality === 'Holy See' ? 'selected' : ''); ?>>Holy See</option>
<option value="Honduras" <?php echo e($candidate->candidateDetail->nationality === 'Honduras' ? 'selected' : ''); ?>>Honduras</option>
<option value="Hong Kong" <?php echo e($candidate->candidateDetail->nationality === 'Hong Kong' ? 'selected' : ''); ?>>Hong Kong</option>
<option value="Hungary" <?php echo e($candidate->candidateDetail->nationality === 'Hungary' ? 'selected' : ''); ?>>Hungary</option>
<option value="Iceland" <?php echo e($candidate->candidateDetail->nationality === 'Iceland' ? 'selected' : ''); ?>>Iceland</option>
<option value="India" <?php echo e($candidate->candidateDetail->nationality === 'India' ? 'selected' : ''); ?>>India</option>
<option value="Indonesia" <?php echo e($candidate->candidateDetail->nationality === 'Indonesia' ? 'selected' : ''); ?>>Indonesia</option>
<option value="Iran" <?php echo e($candidate->candidateDetail->nationality === 'Iran' ? 'selected' : ''); ?>>Iran</option>
<option value="Iraq" <?php echo e($candidate->candidateDetail->nationality === 'Iraq' ? 'selected' : ''); ?>>Iraq</option>

<option value="Ireland" <?php echo e($candidate->candidateDetail->nationality === 'Ireland' ? 'selected' : ''); ?>>Ireland</option>
<option value="Israel" <?php echo e($candidate->candidateDetail->nationality === 'Israel' ? 'selected' : ''); ?>>Israel</option>
<option value="Italy" <?php echo e($candidate->candidateDetail->nationality === 'Italy' ? 'selected' : ''); ?>>Italy</option>
<option value="Jamaica" <?php echo e($candidate->candidateDetail->nationality === 'Jamaica' ? 'selected' : ''); ?>>Jamaica</option>
<option value="Japan" <?php echo e($candidate->candidateDetail->nationality === 'Japan' ? 'selected' : ''); ?>>Japan</option>
<option value="Jordan" <?php echo e($candidate->candidateDetail->nationality === 'Jordan' ? 'selected' : ''); ?>>Jordan</option>

<option value="Kazakhstan" <?php echo e($candidate->candidateDetail->nationality === 'Kazakhstan' ? 'selected' : ''); ?>>Kazakhstan</option>
<option value="Kenya" <?php echo e($candidate->candidateDetail->nationality === 'Kenya' ? 'selected' : ''); ?>>Kenya</option>
<option value="Kiribati" <?php echo e($candidate->candidateDetail->nationality === 'Kiribati' ? 'selected' : ''); ?>>Kiribati</option>
<option value="Korea, Democratic People's Republic of" <?php echo e($candidate->candidateDetail->nationality === "Korea, Democratic People's Republic of" ? 'selected' : ''); ?>>Korea, Democratic People's Republic of</option>
<option value="Korea, Republic of" <?php echo e($candidate->candidateDetail->nationality === 'Korea, Republic of' ? 'selected' : ''); ?>>Korea, Republic of</option>
<option value="Kuwait" <?php echo e($candidate->candidateDetail->nationality === 'Kuwait' ? 'selected' : ''); ?>>Kuwait</option>
<option value="Kyrgyzstan" <?php echo e($candidate->candidateDetail->nationality === 'Kyrgyzstan' ? 'selected' : ''); ?>>Kyrgyzstan</option>
<option value="Lao People's Democratic Republic" <?php echo e($candidate->candidateDetail->nationality === "Lao People's Democratic Republic" ? 'selected' : ''); ?>>Lao People's Democratic Republic</option>

<option value="Latvia" <?php echo e($candidate->candidateDetail->nationality === 'Latvia' ? 'selected' : ''); ?>>Latvia</option>
<option value="Lebanon" <?php echo e($candidate->candidateDetail->nationality === 'Lebanon' ? 'selected' : ''); ?>>Lebanon</option>
<option value="Lesotho" <?php echo e($candidate->candidateDetail->nationality === 'Lesotho' ? 'selected' : ''); ?>>Lesotho</option>
<option value="Liberia" <?php echo e($candidate->candidateDetail->nationality === 'Liberia' ? 'selected' : ''); ?>>Liberia</option>
<option value="Libyan Arab Jamahiriya" <?php echo e($candidate->candidateDetail->nationality === 'Libyan Arab Jamahiriya' ? 'selected' : ''); ?>>Libyan Arab Jamahiriya</option>
<option value="Liechtenstein" <?php echo e($candidate->candidateDetail->nationality === 'Liechtenstein' ? 'selected' : ''); ?>>Liechtenstein</option>
<option value="Lithuania" <?php echo e($candidate->candidateDetail->nationality === 'Lithuania' ? 'selected' : ''); ?>>Lithuania</option>
<option value="Luxembourg" <?php echo e($candidate->candidateDetail->nationality === 'Luxembourg' ? 'selected' : ''); ?>>Luxembourg</option>
<option value="Macao" <?php echo e($candidate->candidateDetail->nationality === 'Macao' ? 'selected' : ''); ?>>Macao</option>
<option value="Macedonia" <?php echo e($candidate->candidateDetail->nationality === 'Macedonia' ? 'selected' : ''); ?>>Macedonia</option>
<option value="Madagascar" <?php echo e($candidate->candidateDetail->nationality === 'Madagascar' ? 'selected' : ''); ?>>Madagascar</option>
<option value="Malawi" <?php echo e($candidate->candidateDetail->nationality === 'Malawi' ? 'selected' : ''); ?>>Malawi</option>
<option value="Malaysia" <?php echo e($candidate->candidateDetail->nationality === 'Malaysia' ? 'selected' : ''); ?>>Malaysia</option>
<option value="Maldives" <?php echo e($candidate->candidateDetail->nationality === 'Maldives' ? 'selected' : ''); ?>>Maldives</option>
<option value="Mali" <?php echo e($candidate->candidateDetail->nationality === 'Mali' ? 'selected' : ''); ?>>Mali</option>
<option value="Malta" <?php echo e($candidate->candidateDetail->nationality === 'Malta' ? 'selected' : ''); ?>>Malta</option>
<option value="Marshall Islands" <?php echo e($candidate->candidateDetail->nationality === 'Marshall Islands' ? 'selected' : ''); ?>>Marshall Islands</option>
<option value="Martinique" <?php echo e($candidate->candidateDetail->nationality === 'Martinique' ? 'selected' : ''); ?>>Martinique</option>
<option value="Mauritania" <?php echo e($candidate->candidateDetail->nationality === 'Mauritania' ? 'selected' : ''); ?>>Mauritania</option>
<option value="Mauritius" <?php echo e($candidate->candidateDetail->nationality === 'Mauritius' ? 'selected' : ''); ?>>Mauritius</option>
<option value="Mayotte" <?php echo e($candidate->candidateDetail->nationality === 'Mayotte' ? 'selected' : ''); ?>>Mayotte</option>
<option value="Mexico" <?php echo e($candidate->candidateDetail->nationality === 'Mexico' ? 'selected' : ''); ?>>Mexico</option>
<option value="Micronesia" <?php echo e($candidate->candidateDetail->nationality === 'Micronesia' ? 'selected' : ''); ?>>Micronesia</option>
<option value="Moldova" <?php echo e($candidate->candidateDetail->nationality === 'Moldova' ? 'selected' : ''); ?>>Moldova</option>
<option value="Monaco" <?php echo e($candidate->candidateDetail->nationality === 'Monaco' ? 'selected' : ''); ?>>Monaco</option>
<option value="Mongolia" <?php echo e($candidate->candidateDetail->nationality === 'Mongolia' ? 'selected' : ''); ?>>Mongolia</option>
<option value="Montserrat" <?php echo e($candidate->candidateDetail->nationality === 'Montserrat' ? 'selected' : ''); ?>>Montserrat</option>
<option value="Morocco" <?php echo e($candidate->candidateDetail->nationality === 'Morocco' ? 'selected' : ''); ?>>Morocco</option>
<option value="Mozambique" <?php echo e($candidate->candidateDetail->nationality === 'Mozambique' ? 'selected' : ''); ?>>Mozambique</option>
<option value="Myanmar" <?php echo e($candidate->candidateDetail->nationality === 'Myanmar' ? 'selected' : ''); ?>>Myanmar</option>
<option value="Namibia" <?php echo e($candidate->candidateDetail->nationality === 'Namibia' ? 'selected' : ''); ?>>Namibia</option>
<option value="Nauru" <?php echo e($candidate->candidateDetail->nationality === 'Nauru' ? 'selected' : ''); ?>>Nauru</option>
<option value="Nepal" <?php echo e($candidate->candidateDetail->nationality === 'Nepal' ? 'selected' : ''); ?>>Nepal</option>
<option value="Netherlands" <?php echo e($candidate->candidateDetail->nationality === 'Netherlands' ? 'selected' : ''); ?>>Netherlands</option>
<option value="Netherlands Antilles" <?php echo e($candidate->candidateDetail->nationality === 'Netherlands Antilles' ? 'selected' : ''); ?>>Netherlands Antilles</option>
<option value="New Caledonia" <?php echo e($candidate->candidateDetail->nationality === 'New Caledonia' ? 'selected' : ''); ?>>New Caledonia</option>
<option value="New Zealand" <?php echo e($candidate->candidateDetail->nationality === 'New Zealand' ? 'selected' : ''); ?>>New Zealand</option>
<option value="Nicaragua" <?php echo e($candidate->candidateDetail->nationality === 'Nicaragua' ? 'selected' : ''); ?>>Nicaragua</option>
<option value="Niger" <?php echo e($candidate->candidateDetail->nationality === 'Niger' ? 'selected' : ''); ?>>Niger</option>
<option value="Nigeria" <?php echo e($candidate->candidateDetail->nationality === 'Nigeria' ? 'selected' : ''); ?>>Nigeria</option>
<option value="Niue" <?php echo e($candidate->candidateDetail->nationality === 'Niue' ? 'selected' : ''); ?>>Niue</option>
<option value="Norfolk Island" <?php echo e($candidate->candidateDetail->nationality === 'Norfolk Island' ? 'selected' : ''); ?>>Norfolk Island</option>
<option value="Northern Mariana Islands" <?php echo e($candidate->candidateDetail->nationality === 'Northern Mariana Islands' ? 'selected' : ''); ?>>Northern Mariana Islands</option>
<option value="Norway" <?php echo e($candidate->candidateDetail->nationality === 'Norway' ? 'selected' : ''); ?>>Norway</option>
<option value="Oman" <?php echo e($candidate->candidateDetail->nationality === 'Oman' ? 'selected' : ''); ?>>Oman</option>
<option value="Pakistan" <?php echo e($candidate->candidateDetail->nationality === 'Pakistan' ? 'selected' : ''); ?>>Pakistan</option>
<option value="Palau" <?php echo e($candidate->candidateDetail->nationality === 'Palau' ? 'selected' : ''); ?>>Palau</option>
<option value="Panama" <?php echo e($candidate->candidateDetail->nationality === 'Panama' ? 'selected' : ''); ?>>Panama</option>
<option value="Papua New Guinea" <?php echo e($candidate->candidateDetail->nationality === 'Papua New Guinea' ? 'selected' : ''); ?>>Papua New Guinea</option>
<option value="Paraguay" <?php echo e($candidate->candidateDetail->nationality === 'Paraguay' ? 'selected' : ''); ?>>Paraguay</option>
<option value="Peru" <?php echo e($candidate->candidateDetail->nationality === 'Peru' ? 'selected' : ''); ?>>Peru</option>
<option value="Philippines" <?php echo e($candidate->candidateDetail->nationality === 'Philippines' ? 'selected' : ''); ?>>Philippines</option>
<option value="Pitcairn" <?php echo e($candidate->candidateDetail->nationality === 'Pitcairn' ? 'selected' : ''); ?>>Pitcairn</option>
<option value="Poland" <?php echo e($candidate->candidateDetail->nationality === 'Poland' ? 'selected' : ''); ?>>Poland</option>
<option value="Portugal" <?php echo e($candidate->candidateDetail->nationality === 'Portugal' ? 'selected' : ''); ?>>Portugal</option>
<option value="Puerto Rico" <?php echo e($candidate->candidateDetail->nationality === 'Puerto Rico' ? 'selected' : ''); ?>>Puerto Rico</option>
<option value="Qatar" <?php echo e($candidate->candidateDetail->nationality === 'Qatar' ? 'selected' : ''); ?>>Qatar</option>
<option value="Reunion" <?php echo e($candidate->candidateDetail->nationality === 'Reunion' ? 'selected' : ''); ?>>Reunion</option>
<option value="Romania" <?php echo e($candidate->candidateDetail->nationality === 'Romania' ? 'selected' : ''); ?>>Romania</option>
<option value="Russia" <?php echo e($candidate->candidateDetail->nationality === 'Russia' ? 'selected' : ''); ?>>Russian Federation</option>
<option value="Rwanda" <?php echo e($candidate->candidateDetail->nationality === 'Rwanda' ? 'selected' : ''); ?>>Rwanda</option>
<option value="Saint Kitts and Nevis" <?php echo e($candidate->candidateDetail->nationality === 'Saint Kitts and Nevis' ? 'selected' : ''); ?>>Saint Kitts and Nevis</option>
<option value="Saint LUCIA" <?php echo e($candidate->candidateDetail->nationality === 'Saint LUCIA' ? 'selected' : ''); ?>>Saint LUCIA</option>
<option value="Saint Vincent" <?php echo e($candidate->candidateDetail->nationality === 'Saint Vincent' ? 'selected' : ''); ?>>Saint Vincent and the Grenadines</option>
<option value="Samoa" <?php echo e($candidate->candidateDetail->nationality === 'Samoa' ? 'selected' : ''); ?>>Samoa</option>
<option value="San Marino" <?php echo e($candidate->candidateDetail->nationality === 'San Marino' ? 'selected' : ''); ?>>San Marino</option>
<option value="Sao Tome and Principe" <?php echo e($candidate->candidateDetail->nationality === 'Sao Tome and Principe' ? 'selected' : ''); ?>>Sao Tome and Principe</option>
<option value="Saudi Arabia" <?php echo e($candidate->candidateDetail->nationality === 'Saudi Arabia' ? 'selected' : ''); ?>>Saudi Arabia</option>
<option value="Senegal" <?php echo e($candidate->candidateDetail->nationality === 'Senegal' ? 'selected' : ''); ?>>Senegal</option>
<option value="Seychelles" <?php echo e($candidate->candidateDetail->nationality === 'Seychelles' ? 'selected' : ''); ?>>Seychelles</option>
<option value="Sierra" <?php echo e($candidate->candidateDetail->nationality === 'Sierra' ? 'selected' : ''); ?>>Sierra Leone</option>
<option value="Singapore" <?php echo e($candidate->candidateDetail->nationality === 'Singapore' ? 'selected' : ''); ?>>Singapore</option>
<option value="Slovakia" <?php echo e($candidate->candidateDetail->nationality === 'Slovakia' ? 'selected' : ''); ?>>Slovakia (Slovak Republic)</option>
<option value="Slovenia" <?php echo e($candidate->candidateDetail->nationality === 'Slovenia' ? 'selected' : ''); ?>>Slovenia</option>
<option value="Solomon Islands" <?php echo e($candidate->candidateDetail->nationality === 'Solomon Islands' ? 'selected' : ''); ?>>Solomon Islands</option>
<option value="Somalia" <?php echo e($candidate->candidateDetail->nationality === 'Somalia' ? 'selected' : ''); ?>>Somalia</option>
<option value="South Africa" <?php echo e($candidate->candidateDetail->nationality === 'South Africa' ? 'selected' : ''); ?>>South Africa</option>
<option value="South Georgia" <?php echo e($candidate->candidateDetail->nationality === 'South Georgia' ? 'selected' : ''); ?>>South Georgia and the South Sandwich Islands</option>
<option value="Span" <?php echo e($candidate->candidateDetail->nationality === 'Span' ? 'selected' : ''); ?>>Spain</option>
<option value="SriLanka" <?php echo e($candidate->candidateDetail->nationality === 'SriLanka' ? 'selected' : ''); ?>>Sri Lanka</option>
<option value="St. Helena" <?php echo e($candidate->candidateDetail->nationality === 'St. Helena' ? 'selected' : ''); ?>>St. Helena</option>
<option value="St. Pierre and Miguelon" <?php echo e($candidate->candidateDetail->nationality === 'St. Pierre and Miguelon' ? 'selected' : ''); ?>>St. Pierre and Miquelon</option>
<option value="Sudan" <?php echo e($candidate->candidateDetail->nationality === 'Sudan' ? 'selected' : ''); ?>>Sudan</option>
<option value="Suriname" <?php echo e($candidate->candidateDetail->nationality === 'Suriname' ? 'selected' : ''); ?>>Suriname</option>
<option value="Svalbard" <?php echo e($candidate->candidateDetail->nationality === 'Svalbard' ? 'selected' : ''); ?>>Svalbard and Jan Mayen Islands</option>
<option value="Swaziland" <?php echo e($candidate->candidateDetail->nationality === 'Swaziland' ? 'selected' : ''); ?>>Swaziland</option>
<option value="Sweden" <?php echo e($candidate->candidateDetail->nationality === 'Sweden' ? 'selected' : ''); ?>>Sweden</option>
<option value="Switzerland" <?php echo e($candidate->candidateDetail->nationality === 'Switzerland' ? 'selected' : ''); ?>>Switzerland</option>
<option value="Syria" <?php echo e($candidate->candidateDetail->nationality === 'Syria' ? 'selected' : ''); ?>>Syrian Arab Republic</option>
<option value="Taiwan" <?php echo e($candidate->candidateDetail->nationality === 'Taiwan' ? 'selected' : ''); ?>>Taiwan, Province of China</option>
<option value="Tajikistan" <?php echo e($candidate->candidateDetail->nationality === 'Tajikistan' ? 'selected' : ''); ?>>Tajikistan</option>
<option value="Tanzania" <?php echo e($candidate->candidateDetail->nationality === 'Tanzania' ? 'selected' : ''); ?>>Tanzania, United Republic of</option>
<option value="Thailand" <?php echo e($candidate->candidateDetail->nationality === 'Thailand' ? 'selected' : ''); ?>>Thailand</option>
<option value="Togo" <?php echo e($candidate->candidateDetail->nationality === 'Togo' ? 'selected' : ''); ?>>Togo</option>
<option value="Tokelau" <?php echo e($candidate->candidateDetail->nationality === 'Tokelau' ? 'selected' : ''); ?>>Tokelau</option>
<option value="Tonga" <?php echo e($candidate->candidateDetail->nationality === 'Tonga' ? 'selected' : ''); ?>>Tonga</option>
<option value="Trinidad and Tobago" <?php echo e($candidate->candidateDetail->nationality === 'Trinidad and Tobago' ? 'selected' : ''); ?>>Trinidad and Tobago</option>
<option value="Tunisia" <?php echo e($candidate->candidateDetail->nationality === 'Tunisia' ? 'selected' : ''); ?>>Tunisia</option>
<option value="Turkey" <?php echo e($candidate->candidateDetail->nationality === 'Turkey' ? 'selected' : ''); ?>>Turkey</option>
<option value="Turkmenistan" <?php echo e($candidate->candidateDetail->nationality === 'Turkmenistan' ? 'selected' : ''); ?>>Turkmenistan</option>
<option value="Turks and Caicos" <?php echo e($candidate->candidateDetail->nationality === 'Turks and Caicos' ? 'selected' : ''); ?>>Turks and Caicos Islands</option>
<option value="Tuvalu" <?php echo e($candidate->candidateDetail->nationality === 'Tuvalu' ? 'selected' : ''); ?>>Tuvalu</option>
<option value="Uganda" <?php echo e($candidate->candidateDetail->nationality === 'Uganda' ? 'selected' : ''); ?>>Uganda</option>
<option value="Ukraine" <?php echo e($candidate->candidateDetail->nationality === 'Ukraine' ? 'selected' : ''); ?>>Ukraine</option>
<option value="United Arab Emirates" <?php echo e($candidate->candidateDetail->nationality === 'United Arab Emirates' ? 'selected' : ''); ?>>United Arab Emirates</option>
<option value="United Kingdom" <?php echo e($candidate->candidateDetail->nationality === 'United Kingdom' ? 'selected' : ''); ?>>United Kingdom</option>
<option value="United States" <?php echo e($candidate->candidateDetail->nationality === 'United States' ? 'selected' : ''); ?>>United States</option>
<option value="United States Minor Outlying Islands" <?php echo e($candidate->candidateDetail->nationality === 'United States Minor Outlying Islands' ? 'selected' : ''); ?>>United States Minor Outlying Islands</option>
<option value="Uruguay" <?php echo e($candidate->candidateDetail->nationality === 'Uruguay' ? 'selected' : ''); ?>>Uruguay</option>
<option value="Uzbekistan" <?php echo e($candidate->candidateDetail->nationality === 'Uzbekistan' ? 'selected' : ''); ?>>Uzbekistan</option>
<option value="Vanuatu" <?php echo e($candidate->candidateDetail->nationality === 'Vanuatu' ? 'selected' : ''); ?>>Vanuatu</option>
<option value="Venezuela" <?php echo e($candidate->candidateDetail->nationality === 'Venezuela' ? 'selected' : ''); ?>>Venezuela</option>
<option value="Vietnam" <?php echo e($candidate->candidateDetail->nationality === 'Vietnam' ? 'selected' : ''); ?>>Viet Nam</option>
<option value="Virgin Islands (British)" <?php echo e($candidate->candidateDetail->nationality === 'Virgin Islands (British)' ? 'selected' : ''); ?>>Virgin Islands (British)</option>
<option value="Virgin Islands (U.S)" <?php echo e($candidate->candidateDetail->nationality === 'Virgin Islands (U.S)' ? 'selected' : ''); ?>>Virgin Islands (U.S.)</option>
<option value="Wallis and Futana Islands" <?php echo e($candidate->candidateDetail->nationality === 'Wallis and Futuna Islands' ? 'selected' : ''); ?>>Wallis and Futuna Islands</option>
<option value="Western Sahara" <?php echo e($candidate->candidateDetail->nationality === 'Western Sahara' ? 'selected' : ''); ?>>Western Sahara</option>
<option value="Yemen" <?php echo e($candidate->candidateDetail->nationality === 'Yemen' ? 'selected' : ''); ?>>Yemen</option>
<option value="Serbia" <?php echo e($candidate->candidateDetail->nationality === 'Serbia' ? 'selected' : ''); ?>>Serbia</option>
<option value="Zambia" <?php echo e($candidate->candidateDetail->nationality === 'Zambia' ? 'selected' : ''); ?>>Zambia</option>
<option value="Zimbabwe" <?php echo e($candidate->candidateDetail->nationality === 'Zimbabwe' ? 'selected' : ''); ?>>Zimbabwe</option>
                                                </select>
                                                <i class="fs-input-icon fa fa-globe-americas"></i>
                                                  <?php $__errorArgs = ['nationality'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback"><?php echo e($message); ?></span>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                            </div>

                                                        </div>
                                                    </div>

                                                   <div class="col-xl-4 col-lg-6 col-md-12">
    <div class="form-group city-outer-bx has-feedback">
        <label>UAE Visa Status?</label>
        <div class="row twm-form-radio-inline">
            <div class="form-check">
                <input class="form-check-input" type="radio" name="uae_status" id="residenceVisa" value="residence_visa" <?php echo e(old('uae_status', $candidateDetail->uae_status) === 'residence_visa' ? 'checked' : ''); ?>>
                <label class="form-check-label" for="residenceVisa">
                    Residence Visa
                </label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="uae_status" id="visitingVisa" value="visiting_visa" <?php echo e(old('uae_status', $candidateDetail->uae_status) === 'visiting_visa' ? 'checked' : ''); ?>>
                <label class="form-check-label" for="visitingVisa">
                    Visiting Visa
                </label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="uae_status" id="outOfUAE" value="out_of_uae" <?php echo e(old('uae_status', $candidateDetail->uae_status) === 'out_of_uae' ? 'checked' : ''); ?>>
                <label class="form-check-label" for="outOfUAE">
                    Out of UAE
                </label>
            </div>
        </div>
        <?php $__errorArgs = ['uae_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>

<div id="expiryDateInput" style="display: none;">
    <div class="col-xl-4 col-lg-6 col-md-12">
        <div class="form-group city-outer-bx has-feedback">
            <label>UAE Visa Status Expiry Date</label>
            <div class="ls-inputicon-box">
                <input class="form-control" type="date" name="uae_status_expiry_date" id="uae_status_expiry_date" value="<?php echo e(old('uae_status_expiry_date', $candidateDetail->uae_status_expiry_date)); ?>">
                <i class="fs-input-icon fa fa-calendar"></i>
            </div>
        </div>
    </div>
</div>

<div class="col-xl-4 col-lg-6 col-md-12">
    <div class="form-group city-outer-bx has-feedback">
        <label>Do you have a UAE driving license?</label>
        <div class="row twm-form-radio-inline">
            <div class="form-check">
                <input type="radio" class="form-check-input" id="driving-licence-yes" name="driving_licence" value="yes" <?php echo e($candidateDetail->driving_licence === 'yes' ? 'checked' : ''); ?>>
                <label class="form-check-label" for="driving-licence-yes">Yes</label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="radio" id="driving-licence-no" name="driving_licence" value="no" <?php echo e($candidateDetail->driving_licence === 'no' ? 'checked' : ''); ?>>
                <label for="driving-licence-no" class="form-check-label">No</label>
            </div>
        </div>
        <?php $__errorArgs = ['driving_licence'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>

<div id="driving_licence_expiryDate" style="display: <?php echo e($candidateDetail->driving_licence === 'yes' ? 'block' : 'none'); ?>">
    <div class="col-xl-4 col-lg-6 col-md-12">
        <div class="form-group city-outer-bx has-feedback">
            <label>UAE driving license Expiry Date</label>
            <div class="ls-inputicon-box">
                <input class="form-control" type="date" name="driving_licence_expiry_date" id="driving_licence_expiry_date" value="<?php echo e(old('driving_licence_expiry_date', $candidateDetail->driving_licence_expiry_date)); ?>">
                <i class="fs-input-icon fa fa-calendar"></i>
            </div>
        </div>
    </div>
</div>

<div class="col-xl-4 col-lg-6 col-md-12">
    <div class="form-group city-outer-bx has-feedback">
        <label>Experience Regions</label>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="experience_region" id="uaeRegion" value="UAE" <?php echo e($candidateDetail->experience_region === 'UAE' ? 'checked' : ''); ?>>
            <label class="form-check-label" for="uaeRegion">
                UAE
            </label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="experience_region" id="gccRegion" value="GCC" <?php echo e($candidateDetail->experience_region === 'GCC' ? 'checked' : ''); ?>>
            <label class="form-check-label" for="gccRegion">
                GCC
            </label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="experience_region" id="europeRegion" value="Europe" <?php echo e($candidateDetail->experience_region === 'Europe' ? 'checked' : ''); ?>>
            <label class="form-check-label" for="europeRegion">
                Europe
            </label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="experience_region" id="othersRegion" value="Others" <?php echo e($candidateDetail->experience_region === 'Others' ? 'checked' : ''); ?>>
            <label class="form-check-label" for="othersRegion">
                Others
            </label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="experience_region" id="noExperience" value="no" <?php echo e($candidateDetail->experience_region === 'no' ? 'checked' : ''); ?>>
            <label class="form-check-label" for="noExperience">
                No Experience
            </label>
        </div>
        <div id="experienceYearsSelect" style="display: <?php echo e($candidateDetail->experience_region === 'no' ? 'none' : 'block'); ?>">
            <label>Experience in Years</label>
            <div class="ls-inputicon-box">
                <select class="wt-select-box selectpicker" name="experience_years" id="" data-live-search="true" title="" data-bv-field="size">
                    <?php for($i = 1; $i <= 50; $i++): ?>
                        <option value="<?php echo e($i); ?>" <?php echo e($candidateDetail->experience_years == $i ? 'selected' : ''); ?>><?php echo e($i); ?> <?php echo e($i === 1 ? 'Year' : 'Years'); ?></option>
                    <?php endfor; ?>
                </select>
                <i class="fs-input-icon fa fa-user-edit"></i>
            </div>
        </div>
    </div>
</div>



<div class="col-xl-4 col-lg-6 col-md-12">
    <div class="form-group city-outer-bx has-feedback">
        <label>Language Known</label>
        <div class="ls-inputicon-box">
            <select class="wt-select-box selectpicker" data-live-search="true" title="Nothing Selected" id="autocomplete" name="languages_known[]" multiple="multiple" data-bv-field="size">
                <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($language->name); ?>" <?php echo e(is_array($selectedLanguages) && in_array($language->name, $selectedLanguages) ? 'selected' : ''); ?>>
                        <?php echo e($language->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <i class="fs-input-icon fa fa-language"></i>
        </div>
        <?php $__errorArgs = ['languages_known'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>


          <!-- Qualification Field -->
    <div class="col-xl-4 col-lg-6 col-md-12">
        <div class="form-group city-outer-bx has-feedback">
            <label>Qualification</label>
            <div class="ls-inputicon-box">
                <input class="form-control" name="qualification" type="text" placeholder="Qualification" value="<?php echo e($candidateDetail->qualification); ?>">
                <i class="fs-input-icon fa fa-user-graduate"></i>
            </div>
            <?php $__errorArgs = ['qualification'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
<div class="col-xl-4 col-lg-6 col-md-12">
    <div class="form-group city-outer-bx has-feedback">
        <label>Gender</label>
        <div class="ls-inputicon-box">
            <select id="gender" name="gender" class="wt-select-box selectpicker" data-live-search="true" title="Gender" data-bv-field="size">
                <option class="bs-title-option" value="">Gender</option>
                <option value="Male" <?php echo e($candidateDetail->gender === 'Male' ? 'selected' : ''); ?>>Male</option>
                <option value="Female" <?php echo e($candidateDetail->gender === 'Female' ? 'selected' : ''); ?>>Female</option>
                <option value="Any" <?php echo e($candidateDetail->gender === 'Any' ? 'selected' : ''); ?>>Any</option>
            </select>
            <i class="fs-input-icon fa fa-venus-mars"></i>
        </div>
    </div>
</div>



<div class="col-xl-12 col-lg-6 col-md-12">
    <div class="form-group city-outer-bx has-feedback">
        <label>Upload Resume</label>
        <div class="ls-inputicon-box">
            <input class="form-control" type="file" id="resume" name="resume" placeholder="Click here or drop files to upload">
            <small>*You can upload your resume in PDF or Word format.</small>
            <i class="sl-icon-plus"></i>
        </div>
        <?php $__errorArgs = ['resume'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<div class="col-xl-4 col-lg-6 col-md-12">
    <div class="form-group city-outer-bx has-feedback">
        <label>Current Resume</label>
        <div class="ls-inputicon-box">
<a href="<?php echo e(asset('storage/' . $candidateDetail->resume)); ?>" target="_blank"><?php echo e(__('View Resume')); ?></a>
        </div>

    </div>
</div>

                                            <div class="col-lg-12 col-md-12">
                                                        <div class="text-left">
                                                            <button type="submit" class="site-button">Save Changes</button>
                                                        </div>
                                                    </div>


                                            </div>

                                        </div>
                                    </div>




                                            </div>

                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <!-- OUR BLOG END -->



        </div>
        <!-- CONTENT END -->

      <script>
    // Add an event listener to watch for changes in the radio buttons
    const residenceVisaRadio = document.getElementById('residenceVisa');
    const visitingVisaRadio = document.getElementById('visitingVisa');
    const outOfUAERadio = document.getElementById('outOfUAE');
    const expiryDateInput = document.getElementById('expiryDateInput');

    // Function to update the visibility of the expiry date input based on the initial state
    function updateExpiryDateInputVisibility() {
        if (residenceVisaRadio.checked || visitingVisaRadio.checked) {
            expiryDateInput.style.display = 'block';
        } else if (outOfUAERadio.checked) {
            expiryDateInput.style.display = 'none';
        }
    }

    // Initial setup when the page loads
    updateExpiryDateInputVisibility();

    residenceVisaRadio.addEventListener('change', function () {
        if (this.checked) {
            expiryDateInput.style.display = 'block';
        }
    });

    visitingVisaRadio.addEventListener('change', function () {
        if (this.checked) {
            expiryDateInput.style.display = 'block';
        }
    });

    outOfUAERadio.addEventListener('change', function () {
        if (this.checked) {
            expiryDateInput.style.display = 'none';
        }
    });
</script>


<script>
    // Get the radio buttons and select element
    const radioButtons = document.querySelectorAll('input[name="experience_region"]');
    const experienceYearsSelect = document.getElementById('experienceYearsSelect');

    // Function to toggle the visibility of the select element
    function toggleExperienceYearsVisibility() {
        if (this.value === 'no') {
            experienceYearsSelect.style.display = 'none'; // Hide the select
        } else {
            experienceYearsSelect.style.display = 'block'; // Show the select
        }
    }

    // Add an event listener to each radio button
    radioButtons.forEach(radio => {
        radio.addEventListener('change', toggleExperienceYearsVisibility);
    });

    // Initially hide the select when the page loads if "No Experience" is checked
    if (document.querySelector('input[name="experience_region"]:checked').value === 'no') {
        experienceYearsSelect.style.display = 'none';
    }
</script>




 <script>
        $(document).ready(function() {
            $('#autocomplete').select2({
                placeholder: 'Select Languages',
                allowClear: true,
                tags: true,
            });
        });
    </script>
    <script>
document.addEventListener("DOMContentLoaded", function() {
    // Get the radio buttons for "Yes" and "No"
    var drivingLicenseYes = document.getElementById("driving-licence-yes");
    var drivingLicenseNo = document.getElementById("driving-licence-no");

    // Get the section for the expiry date
    var expiryDateSection = document.getElementById("driving_licence_expiryDate");

    // Add an event listener to the radio buttons
    drivingLicenseYes.addEventListener("change", function() {
        if (drivingLicenseYes.checked) {
            expiryDateSection.style.display = "block";
        } else {
            expiryDateSection.style.display = "none";
        }
    });

    drivingLicenseNo.addEventListener("change", function() {
        if (drivingLicenseNo.checked) {
            expiryDateSection.style.display = "none";
        }
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nihal/Desktop/laravel/best4uhr/resources/views/candidate/details/edit.blade.php ENDPATH**/ ?>