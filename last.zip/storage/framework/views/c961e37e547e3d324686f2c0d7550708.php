<?php $__env->startSection('content'); ?>
        <!-- Page Content Holder -->
        <div id="content">

            <div class="content-admin-main">

            	<div class="wt-admin-right-page-header clearfix">
                    <h2>Manage Jobs</h2>
                    <div class="breadcrumbs"><a href="#">Home</a><a href="#">Dashboard</a><span>Job Submission Form</span></div>
                </div>

                <!--Logo and Cover image-->
                <!-- <div class="panel panel-default">
                    <div class="panel-heading wt-panel-heading p-a20">
                        <h4 class="panel-tittle m-a0">Logo and Cover image</h4>
                    </div>
                    <div class="panel-body wt-panel-body p-a20 p-b0 m-b30 ">

                        <div class="row">

                            <div class="col-lg-12 col-md-6">
                                <div class="form-group">

                                    <div class="dashboard-profile-pic">
                                        <div class="dashboard-profile-photo">
                                            <img src="images/jobs-company/pic1.jpg" alt="">
                                            <div class="upload-btn-wrapper">
                                                <button class="site-button button-sm">Upload Photo</button>
                                                <input type="file" name="myfile">
                                            </div>
                                        </div>
                                        <p><b>Company Logo :- </b> Max file size is 1MB, Minimum dimension: 136 x 136 And Suitable files are .jpg & .png</p>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-12 col-md-6">
                                <div class="dashboard-cover-pic">
                                    <form action="upload.php" class="dropzone"></form>
                                    <p><b>Background Banner Image :- </b> Max file size is 1MB, Minimum dimension: 770 x 310 And Suitable files are .jpg & .png</p>
                                </div>
                            </div>

                        </div>

                    </div>
                </div>  -->

                <!--Basic Information-->
                <div class="panel panel-default">
                    <div class="panel-heading wt-panel-heading p-a20">
                        <h4 class="panel-tittle m-a0"><i class="fa fa-suitcase"></i>Job Details</h4>
                    </div>
                    <div class="panel-body wt-panel-body p-a20 m-b30 ">
                        <form method="POST" action="<?php echo e(route('admin.jobs.update', $job->id)); ?>">
                             <?php echo csrf_field(); ?>
                             <?php echo method_field('PUT'); ?>
<div class="row">

                                   <!-- Job Category -->
    <div class="col-xl-4 col-lg-6 col-md-12">
        <div class="form-group city-outer-bx has-feedback">
            <label for="employer_id">Company Name</label>
            <div class="ls-inputicon-box">
                <select class="wt-select-box selectpicker" id="employer_id" name="employer_id" data-live-search="true" title="" data-bv-field="size" required>
                    <option disabled selected value="">Select Company</option>
                    <?php $__currentLoopData = $employers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($employer->id); ?>" <?php echo e($job->employer_id == $employer->id ? 'selected' : ''); ?>><?php echo e($employer->company_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <i class="fs-input-icon fa fa-user-tie"></i>
                <?php $__errorArgs = ['employer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
    </div>

                                    <!--Job title-->
                                    <div class="col-xl-4 col-lg-6 col-md-12">
                                        <div class="form-group">
                                            <label for="job_position">Job Position</label>
                                            <div class="ls-inputicon-box">
                                                <input class="form-control" type="text" id="job_position" name="job_position" value="<?php echo e(old('job_position', $job->job_position)); ?>" placeholder="job_position">
                                                <i class="fs-input-icon fa fa-address-card"></i>
                                                 <?php $__errorArgs = ['job_position'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>

                                    <!--Job title-->
                                    <div class="col-xl-4 col-lg-6 col-md-12">
                                        <div class="form-group">
                                            <label>Field of Work</label>
                                            <div class="ls-inputicon-box">
                                                <input class="form-control" type="text" id="field_of_work" name="field_of_work" value="<?php echo e(old('field_of_work', $job->field_of_work)); ?>" placeholder="">
                                                <i class="fs-input-icon fa fa-file-alt"></i>
                                                 <?php $__errorArgs = ['field_of_work'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>

                   <!--Offered Salary-->
                                    <div class="col-xl-4 col-lg-6 col-md-12">
                                        <div class="form-group">
                                            <label>Offered Salary</label>
                                            <div class="ls-inputicon-box">
                                                <input class="form-control" type="text" id="salary" name="salary" value="<?php echo e(old('field_of_work', $job->salary)); ?>" placeholder="Salary">
                                                <i class="fs-input-icon fa fa-dollar-sign"></i>
                                                 <?php $__errorArgs = ['salary'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>
                                    <!--Gender-->
                                    <div class="col-xl-4 col-lg-6 col-md-12">
    <div class="form-group">
        <label for="gender">Gender</label>
        <div class="ls-inputicon-box">
            <select id="gender" name="gender" class="wt-select-box selectpicker" data-live-search="true" title="Gender" data-bv-field="size">
                <option class="bs-title-option" value="">Gender</option>
                <option value="Male" <?php echo e(old('gender', $job->gender) === 'Male' ? 'selected' : ''); ?>>Male</option>
                <option value="Female" <?php echo e(old('gender', $job->gender) === 'Female' ? 'selected' : ''); ?>>Female</option>
                <option value="Any" <?php echo e(old('gender', $job->gender) === 'Any' ? 'selected' : ''); ?>>Any</option>
            </select>
            <i class="fs-input-icon fa fa-venus-mars"></i>
        </div>
    </div>
</div>


                                    <!--Country-->
                                    <div class="col-xl-4 col-lg-6 col-md-12">
                                        <div class="form-group">
                                            <label>Nationality</label>
                                            <div class="ls-inputicon-box">
                                                <select class="wt-select-box selectpicker" id="nationality" name="nationality" data-live-search="true" title="" id="country" data-bv-field="size">
                                                    <option class="bs-title-option" value="" >Nationality</option>
                            <option class="bs-title-option" value="" >Nationality</option>
                                                        <option value="Afghanistan" <?php echo e($job->nationality === 'Afghanistan' ? 'selected' : ''); ?>>Afghanistan</option>
    <option value="Albania" <?php echo e($job->nationality === 'Albania' ? 'selected' : ''); ?>>Albania</option>
    <option value="Algeria" <?php echo e($job->nationality === 'Algeria' ? 'selected' : ''); ?>>Algeria</option>
    <option value="American Samoa" <?php echo e($job->nationality === 'American Samoa' ? 'selected' : ''); ?>>American Samoa</option>
    <option value="Andorra" <?php echo e($job->nationality === 'Andorra' ? 'selected' : ''); ?>>Andorra</option>
    <option value="Angola" <?php echo e($job->nationality === 'Angola' ? 'selected' : ''); ?>>Angola</option>
    <option value="Antarctica" <?php echo e($job->nationality === 'Antarctica' ? 'selected' : ''); ?>>Antarctica</option>
    <option value="Antigua and Barbuda" <?php echo e($job->nationality === 'Antigua and Barbuda' ? 'selected' : ''); ?>>Antigua and Barbuda</option>
    <option value="Argentina" <?php echo e($job->nationality === 'Argentina' ? 'selected' : ''); ?>>Argentina</option>
    <option value="Armenia" <?php echo e($job->nationality === 'Armenia' ? 'selected' : ''); ?>>Armenia</option>
    <option value="Aruba" <?php echo e($job->nationality === 'Aruba' ? 'selected' : ''); ?>>Aruba</option>
    <option value="Australia" <?php echo e($job->nationality === 'Australia' ? 'selected' : ''); ?>>Australia</option>
    <option value="Austria" <?php echo e($job->nationality === 'Austria' ? 'selected' : ''); ?>>Austria</option>
    <option value="Azerbaijan" <?php echo e($job->nationality === 'Azerbaijan' ? 'selected' : ''); ?>>Azerbaijan</option>
    <option value="Bahamas" <?php echo e($job->nationality === 'Bahamas' ? 'selected' : ''); ?>>Bahamas</option>
    <option value="Bahrain" <?php echo e($job->nationality === 'Bahrain' ? 'selected' : ''); ?>>Bahrain</option>
    <option value="Bangladesh" <?php echo e($job->nationality === 'Bangladesh' ? 'selected' : ''); ?>>Bangladesh</option>
    <option value="Barbados" <?php echo e($job->nationality === 'Barbados' ? 'selected' : ''); ?>>Barbados</option>
    <option value="Belarus" <?php echo e($job->nationality === 'Belarus' ? 'selected' : ''); ?>>Belarus</option>
    <option value="Belgium" <?php echo e($job->nationality === 'Belgium' ? 'selected' : ''); ?>>Belgium</option>
    <option value="Belize" <?php echo e($job->nationality === 'Belize' ? 'selected' : ''); ?>>Belize</option>
    <option value="Benin" <?php echo e($job->nationality === 'Benin' ? 'selected' : ''); ?>>Benin</option>
    <option value="Bermuda" <?php echo e($job->nationality === 'Bermuda' ? 'selected' : ''); ?>>Bermuda</option>
    <option value="Bhutan" <?php echo e($job->nationality === 'Bhutan' ? 'selected' : ''); ?>>Bhutan</option>
    <option value="Bolivia" <?php echo e($job->nationality === 'Bolivia' ? 'selected' : ''); ?>>Bolivia</option>
    <option value="Bosnia and Herzegovina" <?php echo e($job->nationality === 'Bosnia and Herzegovina' ? 'selected' : ''); ?>>Bosnia and Herzegovina</option>
    <option value="Botswana" <?php echo e($job->nationality === 'Botswana' ? 'selected' : ''); ?>>Botswana</option>
    <option value="Bouvet Island" <?php echo e($job->nationality === 'Bouvet Island' ? 'selected' : ''); ?>>Bouvet Island</option>
    <option value="Brazil" <?php echo e($job->nationality === 'Brazil' ? 'selected' : ''); ?>>Brazil</option>
    <option value="British Indian Ocean Territory" <?php echo e($job->nationality === 'British Indian Ocean Territory' ? 'selected' : ''); ?>>British Indian Ocean Territory</option>
    <option value="Brunei Darussalam" <?php echo e($job->nationality === 'Brunei Darussalam' ? 'selected' : ''); ?>>Brunei Darussalam</option>
    <option value="Bulgaria" <?php echo e($job->nationality === 'Bulgaria' ? 'selected' : ''); ?>>Bulgaria</option>
    <option value="Burkina Faso" <?php echo e($job->nationality === 'Burkina Faso' ? 'selected' : ''); ?>>Burkina Faso</option>
    <option value="Burundi" <?php echo e($job->nationality === 'Burundi' ? 'selected' : ''); ?>>Burundi</option>
    <option value="Cambodia" <?php echo e($job->nationality === 'Cambodia' ? 'selected' : ''); ?>>Cambodia</option>
    <option value="Cameroon" <?php echo e($job->nationality === 'Cameroon' ? 'selected' : ''); ?>>Cameroon</option>
    <option value="Canada" <?php echo e($job->nationality === 'Canada' ? 'selected' : ''); ?>>Canada</option>
    <option value="Cape Verde" <?php echo e($job->nationality === 'Cape Verde' ? 'selected' : ''); ?>>Cape Verde</option>
    <option value="Cayman Islands" <?php echo e($job->nationality === 'Cayman Islands' ? 'selected' : ''); ?>>Cayman Islands</option>
    <option value="Central African Republic" <?php echo e($job->nationality === 'Central African Republic' ? 'selected' : ''); ?>>Central African Republic</option>
    <option value="Chad" <?php echo e($job->nationality === 'Chad' ? 'selected' : ''); ?>>Chad</option>
    <option value="Chile" <?php echo e($job->nationality === 'Chile' ? 'selected' : ''); ?>>Chile</option>
    <option value="China" <?php echo e($job->nationality === 'China' ? 'selected' : ''); ?>>China</option>
    <option value="Christmas Island" <?php echo e($job->nationality === 'Christmas Island' ? 'selected' : ''); ?>>Christmas Island</option>
    <option value="Cocos (Keeling) Islands" <?php echo e($job->nationality === 'Cocos (Keeling) Islands' ? 'selected' : ''); ?>>Cocos (Keeling) Islands</option>
     <option value="Cambodia" <?php echo e($job->nationality === 'Cambodia' ? 'selected' : ''); ?>>Cambodia</option>
    <option value="Comoros" <?php echo e($job->nationality === 'Comoros' ? 'selected' : ''); ?>>Comoros</option>
    <option value="Congo" <?php echo e($job->nationality === 'Congo' ? 'selected' : ''); ?>>Congo</option>
    <option value="Congo, the Democratic Republic of the" <?php echo e($job->nationality === 'Congo, the Democratic Republic of the' ? 'selected' : ''); ?>>Congo, the Democratic Republic of</option>
    <option value="Cook Islands" <?php echo e($job->nationality === 'Cook Islands' ? 'selected' : ''); ?>>Cook Islands</option>
    <option value="Costa Rica" <?php echo e($job->nationality === 'Costa Rica' ? 'selected' : ''); ?>>Costa Rica</option>
    <option value="Cote d'Ivoire" <?php echo e($job->nationality === "Cote d'Ivoire" ? 'selected' : ''); ?>>Cote d'Ivoire</option>
    <option value="Croatia" <?php echo e($job->nationality === 'Croatia' ? 'selected' : ''); ?>>Croatia (Hrvatska)</option>
    <option value="Cuba" <?php echo e($job->nationality === 'Cuba' ? 'selected' : ''); ?>>Cuba</option>
    <option value="Cyprus" <?php echo e($job->nationality === 'Cyprus' ? 'selected' : ''); ?>>Cyprus</option>
    <option value="Czech Republic" <?php echo e($job->nationality === 'Czech Republic' ? 'selected' : ''); ?>>Czech Republic</option>
    <option value="Denmark" <?php echo e($job->nationality === 'Denmark' ? 'selected' : ''); ?>>Denmark</option>
    <option value="Djibouti" <?php echo e($job->nationality === 'Djibouti' ? 'selected' : ''); ?>>Djibouti</option>
    <option value="Dominica" <?php echo e($job->nationality === 'Dominica' ? 'selected' : ''); ?>>Dominica</option>
    <option value="Dominican Republic" <?php echo e($job->nationality === 'Dominican Republic' ? 'selected' : ''); ?>>Dominican Republic</option>
    <option value="East Timor" <?php echo e($job->nationality === 'East Timor' ? 'selected' : ''); ?>>East Timor</option>
    <option value="Ecuador" <?php echo e($job->nationality === 'Ecuador' ? 'selected' : ''); ?>>Ecuador</option>
    <option value="Egypt" <?php echo e($job->nationality === 'Egypt' ? 'selected' : ''); ?>>Egypt</option>
    <option value="El Salvador" <?php echo e($job->nationality === 'El Salvador' ? 'selected' : ''); ?>>El Salvador</option>
    <option value="Equatorial Guinea" <?php echo e($job->nationality === 'Equatorial Guinea' ? 'selected' : ''); ?>>Equatorial Guinea</option>
    <option value="Eritrea" <?php echo e($job->nationality === 'Eritrea' ? 'selected' : ''); ?>>Eritrea</option>
    <option value="Estonia" <?php echo e($job->nationality === 'Estonia' ? 'selected' : ''); ?>>Estonia</option>
    <option value="Ethiopia" <?php echo e($job->nationality === 'Ethiopia' ? 'selected' : ''); ?>>Ethiopia</option>
    <option value="Falkland Islands (Malvinas)" <?php echo e($job->nationality === 'Falkland Islands (Malvinas)' ? 'selected' : ''); ?>>Falkland Islands</option>
    <option value="Faroe Islands" <?php echo e($job->nationality === 'Faroe Islands' ? 'selected' : ''); ?>>Faroe Islands</option>
    <option value="Fiji" <?php echo e($job->nationality === 'Fiji' ? 'selected' : ''); ?>>Fiji</option>
    <option value="Finland" <?php echo e($job->nationality === 'Finland' ? 'selected' : ''); ?>>Finland</option>
    <option value="France" <?php echo e($job->nationality === 'France' ? 'selected' : ''); ?>>France</option>
    <option value="France, Metropolitan" <?php echo e($job->nationality === 'France, Metropolitan' ? 'selected' : ''); ?>>France, Metropolitan</option>
    <option value="French Guiana" <?php echo e($job->nationality === 'French Guiana' ? 'selected' : ''); ?>>French Guiana</option>
    <option value="French Polynesia" <?php echo e($job->nationality === 'French Polynesia' ? 'selected' : ''); ?>>French Polynesia</option>
    <option value="French Southern Territories" <?php echo e($job->nationality === 'French Southern Territories' ? 'selected' : ''); ?>>French Southern Territories</option>
 <option value="Gabon" <?php echo e($job->nationality === 'Gabon' ? 'selected' : ''); ?>>Gabon</option>
    <option value="Gambia" <?php echo e($job->nationality === 'Gambia' ? 'selected' : ''); ?>>Gambia</option>
    <option value="Georgia" <?php echo e($job->nationality === 'Georgia' ? 'selected' : ''); ?>>Georgia</option>
    <option value="Germany" <?php echo e($job->nationality === 'Germany' ? 'selected' : ''); ?>>Germany</option>
    <option value="Ghana" <?php echo e($job->nationality === 'Ghana' ? 'selected' : ''); ?>>Ghana</option>
    <option value="Gibraltar" <?php echo e($job->nationality === 'Gibraltar' ? 'selected' : ''); ?>>Gibraltar</option>
    <option value="Greece" <?php echo e($job->nationality === 'Greece' ? 'selected' : ''); ?>>Greece</option>
    <option value="Greenland" <?php echo e($job->nationality === 'Greenland' ? 'selected' : ''); ?>>Greenland</option>
    <option value="Grenada" <?php echo e($job->nationality === 'Grenada' ? 'selected' : ''); ?>>Grenada</option>
    <option value="Guadeloupe" <?php echo e($job->nationality === 'Guadeloupe' ? 'selected' : ''); ?>>Guadeloupe</option>
    <option value="Guam" <?php echo e($job->nationality === 'Guam' ? 'selected' : ''); ?>>Guam</option>
    <option value="Guatemala" <?php echo e($job->nationality === 'Guatemala' ? 'selected' : ''); ?>>Guatemala</option>
    <option value="Guinea" <?php echo e($job->nationality === 'Guinea' ? 'selected' : ''); ?>>Guinea</option>
    <option value="Guinea-Bissau" <?php echo e($job->nationality === 'Guinea-Bissau' ? 'selected' : ''); ?>>Guinea-Bissau</option>
    <option value="Guyana" <?php echo e($job->nationality === 'Guyana' ? 'selected' : ''); ?>>Guyana</option>
    <option value="Haiti" <?php echo e($job->nationality === 'Haiti' ? 'selected' : ''); ?>>Haiti</option>
    <option value="Heard and Mc Donald Islands" <?php echo e($job->nationality === 'Heard and Mc Donald Islands' ? 'selected' : ''); ?>>Heard and Mc Donald Islands</option>
    <option value="Holy See (Vatican City State)" <?php echo e($job->nationality === 'Holy See (Vatican City State)' ? 'selected' : ''); ?>>Holy See</option>
    <option value="Honduras" <?php echo e($job->nationality === 'Honduras' ? 'selected' : ''); ?>>Honduras</option>
    <option value="Hong Kong" <?php echo e($job->nationality === 'Hong Kong' ? 'selected' : ''); ?>>Hong Kong</option>
    <option value="Hungary" <?php echo e($job->nationality === 'Hungary' ? 'selected' : ''); ?>>Hungary</option>
    <option value="Iceland" <?php echo e($job->nationality === 'Iceland' ? 'selected' : ''); ?>>Iceland</option>
    <option value="India" <?php echo e($job->nationality === 'India' ? 'selected' : ''); ?>>India</option>
    <option value="Indonesia" <?php echo e($job->nationality === 'Indonesia' ? 'selected' : ''); ?>>Indonesia</option>
    <option value="Iran (Islamic Republic of)" <?php echo e($job->nationality === 'Iran (Islamic Republic of)' ? 'selected' : ''); ?>>Iran</option>
    <option value="Iraq" <?php echo e($job->nationality === 'Iraq' ? 'selected' : ''); ?>>Iraq</option>
    <option value="Ireland" <?php echo e($job->nationality === 'Ireland' ? 'selected' : ''); ?>>Ireland</option>
    <option value="Israel" <?php echo e($job->nationality === 'Israel' ? 'selected' : ''); ?>>Israel</option>
    <option value="Italy" <?php echo e($job->nationality === 'Italy' ? 'selected' : ''); ?>>Italy</option>
    <option value="Jamaica" <?php echo e($job->nationality === 'Jamaica' ? 'selected' : ''); ?>>Jamaica</option>
    <option value="Japan" <?php echo e($job->nationality === 'Japan' ? 'selected' : ''); ?>>Japan</option>
    <option value="Jordan" <?php echo e($job->nationality === 'Jordan' ? 'selected' : ''); ?>>Jordan</option>
    <option value="Kazakhstan" <?php echo e($job->nationality === 'Kazakhstan' ? 'selected' : ''); ?>>Kazakhstan</option>
    <option value="Kenya" <?php echo e($job->nationality === 'Kenya' ? 'selected' : ''); ?>>Kenya</option>
    <option value="Kiribati" <?php echo e($job->nationality === 'Kiribati' ? 'selected' : ''); ?>>Kiribati</option>
    <option value="Korea, Democratic People's Republic of" <?php echo e($job->nationality === "Korea, Democratic People's Republic of" ? 'selected' : ''); ?>>Korea, Democratic People's Republic of</option>
    <option value="Korea, Republic of" <?php echo e($job->nationality === 'Korea, Republic of' ? 'selected' : ''); ?>>Korea, Republic of</option>
    <option value="Kuwait" <?php echo e($job->nationality === 'Kuwait' ? 'selected' : ''); ?>>Kuwait</option>
    <option value="Kyrgyzstan" <?php echo e($job->nationality === 'Kyrgyzstan' ? 'selected' : ''); ?>>Kyrgyzstan</option>
    <option value="Lao People's Democratic Republic" <?php echo e($job->nationality === "Lao People's Democratic Republic" ? 'selected' : ''); ?>>Lao People's Democratic Republic</option>
    <option value="Latvia" <?php echo e($job->nationality === 'Latvia' ? 'selected' : ''); ?>>Latvia</option>
    <option value="Lebanon" <?php echo e($job->nationality === 'Lebanon' ? 'selected' : ''); ?>>Lebanon</option>
    <option value="Lesotho" <?php echo e($job->nationality === 'Lesotho' ? 'selected' : ''); ?>>Lesotho</option>
    <option value="Liberia" <?php echo e($job->nationality === 'Liberia' ? 'selected' : ''); ?>>Liberia</option>
<option value="Libyan Arab Jamahiriya" <?php echo e($job->nationality === 'Libyan Arab Jamahiriya' ? 'selected' : ''); ?>>Libyan Arab Jamahiriya</option>
<option value="Liechtenstein" <?php echo e($job->nationality === 'Liechtenstein' ? 'selected' : ''); ?>>Liechtenstein</option>
<option value="Lithuania" <?php echo e($job->nationality === 'Lithuania' ? 'selected' : ''); ?>>Lithuania</option>
<option value="Luxembourg" <?php echo e($job->nationality === 'Luxembourg' ? 'selected' : ''); ?>>Luxembourg</option>
<option value="Macau" <?php echo e($job->nationality === 'Macau' ? 'selected' : ''); ?>>Macau</option>
<option value="Macedonia, The Former Yugoslav Republic of" <?php echo e($job->nationality === 'Macedonia, The Former Yugoslav Republic of' ? 'selected' : ''); ?>>Macedonia</option>
<option value="Madagascar" <?php echo e($job->nationality === 'Madagascar' ? 'selected' : ''); ?>>Madagascar</option>
<option value="Malawi" <?php echo e($job->nationality === 'Malawi' ? 'selected' : ''); ?>>Malawi</option>
<option value="Malaysia" <?php echo e($job->nationality === 'Malaysia' ? 'selected' : ''); ?>>Malaysia</option>
<option value="Maldives" <?php echo e($job->nationality === 'Maldives' ? 'selected' : ''); ?>>Maldives</option>
<option value="Mali" <?php echo e($job->nationality === 'Mali' ? 'selected' : ''); ?>>Mali</option>
<option value="Malta" <?php echo e($job->nationality === 'Malta' ? 'selected' : ''); ?>>Malta</option>
<option value="Marshall Islands" <?php echo e($job->nationality === 'Marshall Islands' ? 'selected' : ''); ?>>Marshall Islands</option>
<option value="Martinique" <?php echo e($job->nationality === 'Martinique' ? 'selected' : ''); ?>>Martinique</option>
<option value="Mauritania" <?php echo e($job->nationality === 'Mauritania' ? 'selected' : ''); ?>>Mauritania</option>
<option value="Mauritius" <?php echo e($job->nationality === 'Mauritius' ? 'selected' : ''); ?>>Mauritius</option>
<option value="Mayotte" <?php echo e($job->nationality === 'Mayotte' ? 'selected' : ''); ?>>Mayotte</option>
<option value="Mexico" <?php echo e($job->nationality === 'Mexico' ? 'selected' : ''); ?>>Mexico</option>
<option value="Micronesia, Federated States of" <?php echo e($job->nationality === 'Micronesia, Federated States of' ? 'selected' : ''); ?>>Micronesia</option>
<option value="Moldova, Republic of" <?php echo e($job->nationality === 'Moldova, Republic of' ? 'selected' : ''); ?>>Moldova</option>
<option value="Monaco" <?php echo e($job->nationality === 'Monaco' ? 'selected' : ''); ?>>Monaco</option>
<option value="Mongolia" <?php echo e($job->nationality === 'Mongolia' ? 'selected' : ''); ?>>Mongolia</option>
<option value="Montserrat" <?php echo e($job->nationality === 'Montserrat' ? 'selected' : ''); ?>>Montserrat</option>
<option value="Morocco" <?php echo e($job->nationality === 'Morocco' ? 'selected' : ''); ?>>Morocco</option>
<option value="Mozambique" <?php echo e($job->nationality === 'Mozambique' ? 'selected' : ''); ?>>Mozambique</option>
<option value="Myanmar" <?php echo e($job->nationality === 'Myanmar' ? 'selected' : ''); ?>>Myanmar</option>
<option value="Namibia" <?php echo e($job->nationality === 'Namibia' ? 'selected' : ''); ?>>Namibia</option>
<option value="Nauru" <?php echo e($job->nationality === 'Nauru' ? 'selected' : ''); ?>>Nauru</option>
<option value="Nepal" <?php echo e($job->nationality === 'Nepal' ? 'selected' : ''); ?>>Nepal</option>
<option value="Netherlands" <?php echo e($job->nationality === 'Netherlands' ? 'selected' : ''); ?>>Netherlands</option>
<option value="Netherlands Antilles" <?php echo e($job->nationality === 'Netherlands Antilles' ? 'selected' : ''); ?>>Netherlands Antilles</option>
<option value="New Caledonia" <?php echo e($job->nationality === 'New Caledonia' ? 'selected' : ''); ?>>New Caledonia</option>
<option value="New Zealand" <?php echo e($job->nationality === 'New Zealand' ? 'selected' : ''); ?>>New Zealand</option>
<option value="Nicaragua" <?php echo e($job->nationality === 'Nicaragua' ? 'selected' : ''); ?>>Nicaragua</option>
<option value="Niger" <?php echo e($job->nationality === 'Niger' ? 'selected' : ''); ?>>Niger</option>
<option value="Nigeria" <?php echo e($job->nationality === 'Nigeria' ? 'selected' : ''); ?>>Nigeria</option>
<option value="Niue" <?php echo e($job->nationality === 'Niue' ? 'selected' : ''); ?>>Niue</option>
<option value="Norfolk Island" <?php echo e($job->nationality === 'Norfolk Island' ? 'selected' : ''); ?>>Norfolk Island</option>
<option value="Northern Mariana Islands" <?php echo e($job->nationality === 'Northern Mariana Islands' ? 'selected' : ''); ?>>Northern Mariana Islands</option>
<option value="Norway" <?php echo e($job->nationality === 'Norway' ? 'selected' : ''); ?>>Norway</option>
 <option value="Oman" <?php echo e($job->nationality === 'Oman' ? 'selected' : ''); ?>>Oman</option>
    <option value="Pakistan" <?php echo e($job->nationality === 'Pakistan' ? 'selected' : ''); ?>>Pakistan</option>
    <option value="Palau" <?php echo e($job->nationality === 'Palau' ? 'selected' : ''); ?>>Palau</option>
    <option value="Panama" <?php echo e($job->nationality === 'Panama' ? 'selected' : ''); ?>>Panama</option>
    <option value="Papua New Guinea" <?php echo e($job->nationality === 'Papua New Guinea' ? 'selected' : ''); ?>>Papua New Guinea</option>
    <option value="Paraguay" <?php echo e($job->nationality === 'Paraguay' ? 'selected' : ''); ?>>Paraguay</option>
    <option value="Peru" <?php echo e($job->nationality === 'Peru' ? 'selected' : ''); ?>>Peru</option>
    <option value="Philippines" <?php echo e($job->nationality === 'Philippines' ? 'selected' : ''); ?>>Philippines</option>
    <option value="Pitcairn" <?php echo e($job->nationality === 'Pitcairn' ? 'selected' : ''); ?>>Pitcairn</option>
    <option value="Poland" <?php echo e($job->nationality === 'Poland' ? 'selected' : ''); ?>>Poland</option>
    <option value="Portugal" <?php echo e($job->nationality === 'Portugal' ? 'selected' : ''); ?>>Portugal</option>
    <option value="Puerto Rico" <?php echo e($job->nationality === 'Puerto Rico' ? 'selected' : ''); ?>>Puerto Rico</option>
    <option value="Qatar" <?php echo e($job->nationality === 'Qatar' ? 'selected' : ''); ?>>Qatar</option>
    <option value="Reunion" <?php echo e($job->nationality === 'Reunion' ? 'selected' : ''); ?>>Reunion</option>
    <option value="Romania" <?php echo e($job->nationality === 'Romania' ? 'selected' : ''); ?>>Romania</option>
    <option value="Russian Federation" <?php echo e($job->nationality === 'Russian Federation' ? 'selected' : ''); ?>>Russian Federation</option>
    <option value="Rwanda" <?php echo e($job->nationality === 'Rwanda' ? 'selected' : ''); ?>>Rwanda</option>
    <option value="Saint Kitts and Nevis" <?php echo e($job->nationality === 'Saint Kitts and Nevis' ? 'selected' : ''); ?>>Saint Kitts and Nevis</option>
    <option value="Saint LUCIA" <?php echo e($job->nationality === 'Saint LUCIA' ? 'selected' : ''); ?>>Saint LUCIA</option>
    <option value="Saint Vincent and the Grenadines" <?php echo e($job->nationality === 'Saint Vincent and the Grenadines' ? 'selected' : ''); ?>>Saint Vincent and the Grenadines</option>
    <option value="Samoa" <?php echo e($job->nationality === 'Samoa' ? 'selected' : ''); ?>>Samoa</option>
    <option value="San Marino" <?php echo e($job->nationality === 'San Marino' ? 'selected' : ''); ?>>San Marino</option>
    <option value="Sao Tome and Principe" <?php echo e($job->nationality === 'Sao Tome and Principe' ? 'selected' : ''); ?>>Sao Tome and Principe</option>
    <option value="Saudi Arabia" <?php echo e($job->nationality === 'Saudi Arabia' ? 'selected' : ''); ?>>Saudi Arabia</option>
    <option value="Senegal" <?php echo e($job->nationality === 'Senegal' ? 'selected' : ''); ?>>Senegal</option>
    <option value="Seychelles" <?php echo e($job->nationality === 'Seychelles' ? 'selected' : ''); ?>>Seychelles</option>
    <option value="Sierra Leone" <?php echo e($job->nationality === 'Sierra Leone' ? 'selected' : ''); ?>>Sierra Leone</option>
    <option value="Singapore" <?php echo e($job->nationality === 'Singapore' ? 'selected' : ''); ?>>Singapore</option>
    <option value="Slovakia (Slovak Republic)" <?php echo e($job->nationality === 'Slovakia (Slovak Republic)' ? 'selected' : ''); ?>>Slovakia (Slovak Republic)</option>
    <option value="Slovenia" <?php echo e($job->nationality === 'Slovenia' ? 'selected' : ''); ?>>Slovenia</option>
    <option value="Solomon Islands" <?php echo e($job->nationality === 'Solomon Islands' ? 'selected' : ''); ?>>Solomon Islands</option>
    <option value="Somalia" <?php echo e($job->nationality === 'Somalia' ? 'selected' : ''); ?>>Somalia</option>
    <option value="South Africa" <?php echo e($job->nationality === 'South Africa' ? 'selected' : ''); ?>>South Africa</option>
    <option value="South Georgia and the South Sandwich Islands" <?php echo e($job->nationality === 'South Georgia and the South Sandwich Islands' ? 'selected' : ''); ?>>South Georgia and the South Sandwich Islands</option>
    <option value="Spain" <?php echo e($job->nationality === 'Spain' ? 'selected' : ''); ?>>Spain</option>
    <option value="Sri Lanka" <?php echo e($job->nationality === 'Sri Lanka' ? 'selected' : ''); ?>>Sri Lanka</option>
    <option value="St. Helena" <?php echo e($job->nationality === 'St. Helena' ? 'selected' : ''); ?>>St. Helena</option>
    <option value="St. Pierre and Miquelon" <?php echo e($job->nationality === 'St. Pierre and Miquelon' ? 'selected' : ''); ?>>St. Pierre and Miquelon</option>
    <option value="Sudan" <?php echo e($job->nationality === 'Sudan' ? 'selected' : ''); ?>>Sudan</option>
    <option value="Suriname" <?php echo e($job->nationality === 'Suriname' ? 'selected' : ''); ?>>Suriname</option>
    <option value="Svalbard and Jan Mayen Islands" <?php echo e($job->nationality === 'Svalbard and Jan Mayen Islands' ? 'selected' : ''); ?>>Svalbard and Jan Mayen Islands</option>
    <option value="Swaziland" <?php echo e($job->nationality === 'Swaziland' ? 'selected' : ''); ?>>Swaziland</option>
    <option value="Sweden" <?php echo e($job->nationality === 'Sweden' ? 'selected' : ''); ?>>Sweden</option>
<option value="Switzerland" <?php echo e($job->nationality === 'Switzerland' ? 'selected' : ''); ?>>Switzerland</option>
<option value="Syrian Arab Republic" <?php echo e($job->nationality === 'Syrian Arab Republic' ? 'selected' : ''); ?>>Syria</option>
<option value="Taiwan, Province of China" <?php echo e($job->nationality === 'Taiwan, Province of China' ? 'selected' : ''); ?>>Taiwan</option>
<option value="Tajikistan" <?php echo e($job->nationality === 'Tajikistan' ? 'selected' : ''); ?>>Tajikistan</option>
<option value="Tanzania, United Republic of" <?php echo e($job->nationality === 'Tanzania, United Republic of' ? 'selected' : ''); ?>>Tanzania</option>
<option value="Thailand" <?php echo e($job->nationality === 'Thailand' ? 'selected' : ''); ?>>Thailand</option>
<option value="Togo" <?php echo e($job->nationality === 'Togo' ? 'selected' : ''); ?>>Togo</option>
<option value="Tokelau" <?php echo e($job->nationality === 'Tokelau' ? 'selected' : ''); ?>>Tokelau</option>
<option value="Tonga" <?php echo e($job->nationality === 'Tonga' ? 'selected' : ''); ?>>Tonga</option>
<option value="Trinidad and Tobago" <?php echo e($job->nationality === 'Trinidad and Tobago' ? 'selected' : ''); ?>>Trinidad and Tobago</option>
<option value="Tunisia" <?php echo e($job->nationality === 'Tunisia' ? 'selected' : ''); ?>>Tunisia</option>
<option value="Turkey" <?php echo e($job->nationality === 'Turkey' ? 'selected' : ''); ?>>Turkey</option>
<option value="Turkmenistan" <?php echo e($job->nationality === 'Turkmenistan' ? 'selected' : ''); ?>>Turkmenistan</option>
<option value="Turks and Caicos Islands" <?php echo e($job->nationality === 'Turks and Caicos Islands' ? 'selected' : ''); ?>>Turks and Caicos Islands</option>
<option value="Tuvalu" <?php echo e($job->nationality === 'Tuvalu' ? 'selected' : ''); ?>>Tuvalu</option>
<option value="Uganda" <?php echo e($job->nationality === 'Uganda' ? 'selected' : ''); ?>>Uganda</option>
<option value="Ukraine" <?php echo e($job->nationality === 'Ukraine' ? 'selected' : ''); ?>>Ukraine</option>
<option value="United Arab Emirates" <?php echo e($job->nationality === 'United Arab Emirates' ? 'selected' : ''); ?>>United Arab Emirates</option>
<option value="United Kingdom" <?php echo e($job->nationality === 'United Kingdom' ? 'selected' : ''); ?>>United Kingdom</option>
<option value="United States" <?php echo e($job->nationality === 'United States' ? 'selected' : ''); ?>>United States</option>
<option value="United States Minor Outlying Islands" <?php echo e($job->nationality === 'United States Minor Outlying Islands' ? 'selected' : ''); ?>>United States Minor Outlying Islands</option>
<option value="Uruguay" <?php echo e($job->nationality === 'Uruguay' ? 'selected' : ''); ?>>Uruguay</option>
<option value="Uzbekistan" <?php echo e($job->nationality === 'Uzbekistan' ? 'selected' : ''); ?>>Uzbekistan</option>
<option value="Vanuatu" <?php echo e($job->nationality === 'Vanuatu' ? 'selected' : ''); ?>>Vanuatu</option>
<option value="Venezuela" <?php echo e($job->nationality === 'Venezuela' ? 'selected' : ''); ?>>Venezuela</option>
<option value="Viet Nam" <?php echo e($job->nationality === 'Viet Nam' ? 'selected' : ''); ?>>Viet Nam</option>
<option value="Virgin Islands (British)" <?php echo e($job->nationality === 'Virgin Islands (British)' ? 'selected' : ''); ?>>Virgin Islands (British)</option>
<option value="Virgin Islands (U.S.)" <?php echo e($job->nationality === 'Virgin Islands (U.S.)' ? 'selected' : ''); ?>>Virgin Islands (U.S.)</option>
<option value="Wallis and Futuna Islands" <?php echo e($job->nationality === 'Wallis and Futuna Islands' ? 'selected' : ''); ?>>Wallis and Futuna Islands</option>
<option value="Western Sahara" <?php echo e($job->nationality === 'Western Sahara' ? 'selected' : ''); ?>>Western Sahara</option>
<option value="Yemen" <?php echo e($job->nationality === 'Yemen' ? 'selected' : ''); ?>>Yemen</option>
<option value="Serbia" <?php echo e($job->nationality === 'Serbia' ? 'selected' : ''); ?>>Serbia</option>
<option value="Zambia" <?php echo e($job->nationality === 'Zambia' ? 'selected' : ''); ?>>Zambia</option>
<option value="Zimbabwe" <?php echo e($job->nationality === 'Zimbabwe' ? 'selected' : ''); ?>>Zimbabwe</option>
                                                </select>
                                                <i class="fs-input-icon fa fa-globe-americas"></i>
                                                  <?php $__errorArgs = ['nationality'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>

                                    <!--Location-->
                                    <div class="col-xl-4 col-lg-6 col-md-12">
    <div class="form-group">
        <label >Location</label>
        <div class="ls-inputicon-box">
            <select class="wt-select-box selectpicker <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="location" name="location">
                <option value="">Select Location</option>
                <option value="Dubai" <?php echo e(old('location', $job->location) === 'Dubai' ? 'selected' : ''); ?>>Dubai</option>
                <option value="Sharjah" <?php echo e(old('location', $job->location) === 'Sharjah' ? 'selected' : ''); ?>>Sharjah</option>
                <option value="Ajman" <?php echo e(old('location', $job->location) === 'Ajman' ? 'selected' : ''); ?>>Ajman</option>
                <option value="Ras Al Khaimah" <?php echo e(old('location', $job->location) === 'Ras Al Khaimah' ? 'selected' : ''); ?>>Ras Al Khaimah</option>
                <option value="Abu Dhabi" <?php echo e(old('location', $job->location) === 'Abu Dhabi' ? 'selected' : ''); ?>>Abu Dhabi</option>
                <option value="Fujairah" <?php echo e(old('location', $job->location) === 'Fujairah' ? 'selected' : ''); ?>>Fujairah</option>
                <option value="Umm Al Quwain" <?php echo e(old('location', $job->location) === 'Umm Al Quwain' ? 'selected' : ''); ?>>Umm Al Quwain</option>
            </select>
            <i class="fs-input-icon fa fa-map-marker-alt"></i>
        </div>
        <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>


                                    <!--Latitude-->
                                    <div class="col-xl-4 col-lg-6 col-md-12">
                                        <div class="form-group">
                                            <label>Job Code</label>
                                            <div class="ls-inputicon-box">
                                                <input class="form-control" id="job_code" name="job_code" value="<?php echo e(old( 'job_code',$job->job_code)); ?>" type="text" placeholder="Job Code">
                                                <i class="fs-input-icon fa fa-map-pin"></i>
                                                 <?php $__errorArgs = ['job_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>


                                   <!--Description-->
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Requirements</label>
                                            <textarea class="form-control" id="requirements" name="requirements"  rows="3"  placeholder="Greetings! We are Galaxy Software Development Company. We hope you enjoy our services and quality."><?php echo e(old( 'requirements',$job->requirements)); ?></textarea>
                                        </div>
                                    </div>

                                   <!--Start Date-->
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Start Date</label>
                                            <div class="ls-inputicon-box">
                                                <input class="form-control" id="posted_date" name="posted_date"  value="<?php echo e(old( 'posted_date',$job->posted_date)); ?>"  type="date" placeholder="mm/dd/yyyy">

                                                 <?php $__errorArgs = ['posted_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>

                                    <!--End Date-->
                                    <div class="col-md-6">
                                        <div class="form-group ">
                                            <label>End Date</label>
                                            <div class="ls-inputicon-box">
                                                <input class="form-control" id="closing_date" name="closing_date"   value="<?php echo e(old( 'closing_date',$job->closing_date)); ?>" type="date" placeholder="mm/dd/yyyy">

                                                 <?php $__errorArgs = ['closing_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-12 col-md-12">
                                        <div class="text-left">
                                            <button type="submit" class="site-button m-r5">Publish Job</button>

                                        </div>
                                    </div>
                            </div>
                       </form>
                    </div>
                </div>

            </div>

    	</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nihal/Desktop/laravel/best4uhr/resources/views/admin/jobs/edit.blade.php ENDPATH**/ ?>