<?php $__env->startSection('content'); ?>

        <!-- Page Content Holder -->
        <div id="content">

            <div class="content-admin-main">

            	<div class="wt-admin-right-page-header clearfix">
                    <h2>Manage Jobs</h2>
                    <div class="breadcrumbs"><a href="#">Home</a><a href="<?php echo e(route('employer.index')); ?>">Dashboard</a><span>My Job Listing</span></div>
                </div>

                <!--Basic Information-->
                <div class="panel panel-default">
                    <div class="panel-heading wt-panel-heading p-a20">
                        <h4 class="panel-tittle m-a0"><i class="fa fa-suitcase"></i> Job Details</h4>
                    </div>
                    <div class="panel-body wt-panel-body p-a20 m-b30 ">
                        <div class="twm-D_table p-a20 table-responsive">
                            <table id="jobs_bookmark_table" class="table table-bordered twm-bookmark-list-wrap">
                                <thead>
                                    <tr>
                                        <th>Job Title</th>
                                        <th>Field of Work</th>

                       <th>Salary</th>
                <th>Nationality</th>
                <th>Gender</th>
                 <th>Employer</th>
                <th>Status</th>
                                        <th>Created & Expired</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <!--1-->
                                     <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <div class="twm-bookmark-list">

                                                <div class="twm-mid-content">
                                                    <a href="#" class="twm-job-title">
                                                        <h4><?php echo e($job->job_position); ?></h4>
           <p class="twm-bookmark-address">
                                                            <i class="feather-map-pin"></i><?php echo e($job->location); ?>

                                                        </p>

                                                    </a>

                                                </div>

                                            </div>
                                        </td>

                                        <td><?php echo e($job->field_of_work); ?></td>
                                        <td><?php echo e($job->salary); ?></td>
                                        <td><?php echo e($job->nationality); ?></td>
                                        <td><?php echo e($job->gender); ?></td>
                                      <td><?php if($job->employer): ?>
                    <?php echo e($job->employer->company_name); ?>

                <?php else: ?>
                    No Employer Assigned
                <?php endif; ?></td>
                             <td class="twm-jobs-category">
               <span style="background-color:
                <?php if($job->status === 'pending'): ?>
                    orange
                <?php elseif($job->status === 'Open'): ?>
                    green
                <?php elseif($job->status === 'closed'): ?>
                    red
                
                <?php endif; ?>
            " ><?php echo e($job->status); ?></span>
            </td>


                                        <td>
                                            <div><?php echo e($job->posted_date); ?></div>
                                            <div><?php echo e($job->closing_date); ?></div>
                                        </td>

                                        <td>
                                            <div class="twm-table-controls">
                                                <ul class="twm-DT-controls-icon list-unstyled">

                                                    <li>
                                                        <button title="Edit" data-bs-toggle="tooltip" data-bs-placement="top">
                                                           <a href="<?php echo e(route('jobs.edit', $job->id)); ?>"><span class="far fa-edit"></span></a>
                                                        </button>
                                                    </li>
                                                    <li>
                                                        <form method="POST" action="<?php echo e(route('jobs.destroy', $job->id)); ?>" style="display: inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                                                        <button title="Delete" data-bs-toggle="tooltip" data-bs-placement="top"  onclick="return confirm('Are you sure you want to delete this job posting?')">
                                                       <span class="far fa-trash-alt"></span>
                                                        </button>
                                                         </form>
                                                    </li>
                                                </ul>
                                            </div>
                                        </td>
                                    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>

    	</div>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.employer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nihal/Desktop/laravel/best4uhr/resources/views/employer/jobs/index.blade.php ENDPATH**/ ?>