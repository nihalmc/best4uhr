<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('job_applications', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('candidate_id');
            $table->unsignedBigInteger('details_id');
        $table->unsignedBigInteger('job_id');
         $table->string('cover_letter')->nullable();
        $table->string('resume')->nullable();
            $table->timestamps();

             // Define foreign key constraints
        $table->foreign('candidate_id')->references('id')->on('candidates');
         $table->foreign('details_id')->references('id')->on('candidate_details');
        $table->foreign('job_id')->references('id')->on('jobs');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('job_applications');
    }
};
