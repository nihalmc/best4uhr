	
//=== Switcher panal slide function	=====================//
	jQuery(document).ready(function () {	
		jQuery('.switch-btn').on('click', function () { 
			jQuery('.styleswitcher').toggleClass('active');
		});
	});
//=== Switcher panal slide function END	=====================//


//=== Color css change function	=====================//

jQuery( document ).ready(function() {
	
    // Color changer
    jQuery(".skin-1").on('click', function(){
        jQuery(".skin").attr("href", "css/skins-type/skin-1.css");
		jQuery(".logo-header img").attr("src", "images/skins-logo/logo-skin-1.png");
		jQuery(".footer-dark .logo-footer img").attr("src", "images/skins-logo/logo-skin-1-ftr.png");
		jQuery(".footer-light .logo-footer img").attr("src", "images/skins-logo/logo-skin-1.png");
        jQuery(".page-logo a img").attr("src", "images/skins-logo/logo-skin-1.png");
        jQuery(".twm-u-maintenance-content .media a img").attr("src", "images/skins-logo/mainten-logo-1.png");
        jQuery(".header-style-3.h-page-12-hdr .logo-header .logo-header-inner img").attr("src", "images/skins-logo/logo-all.png");
        jQuery(".header-style-3.h-page-15-hdr .logo-header .logo-header-inner img").attr("src", "images/skins-logo/logo-white.png");
        return false;
    });
    
    jQuery(".skin-2").on('click', function(){
        jQuery(".skin").attr("href", "css/skins-type/skin-2.css");
		jQuery(".logo-header img").attr("src", "images/skins-logo/logo-skin-2.png");
		jQuery(".footer-dark .logo-footer img").attr("src", "images/skins-logo/logo-skin-2-ftr.png");
		jQuery(".footer-light .logo-footer img").attr("src", "images/skins-logo/logo-skin-2.png");
        jQuery(".page-logo a img").attr("src", "images/skins-logo/logo-skin-2.png");
        jQuery(".twm-log-reg-logo-head a img").attr("src", "images/skins-logo/logo-skin-2.png");
        jQuery(".twm-u-maintenance-content .media a img").attr("src", "images/skins-logo/mainten-logo-2.png");
        jQuery(".header-style-3.h-page-12-hdr .logo-header .logo-header-inner img").attr("src", "images/skins-logo/logo-all.png");
        jQuery(".header-style-3.h-page-15-hdr .logo-header .logo-header-inner img").attr("src", "images/skins-logo/logo-white.png");
        return false;
    });
    
    jQuery(".skin-3").on('click', function(){
        jQuery(".skin").attr("href", "css/skins-type/skin-3.css");
		jQuery(".logo-header img").attr("src", "images/skins-logo/logo-skin-3.png");
		jQuery(".footer-dark .logo-footer img").attr("src", "images/skins-logo/logo-skin-3-ftr.png");
		jQuery(".footer-light .logo-footer img").attr("src", "images/skins-logo/logo-skin-3.png");
        jQuery(".page-logo a img").attr("src", "images/skins-logo/logo-skin-3.png");
        jQuery(".twm-log-reg-logo-head a img").attr("src", "images/skins-logo/logo-skin-3.png");
        jQuery(".twm-u-maintenance-content .media a img").attr("src", "images/skins-logo/mainten-logo-3.png");
        jQuery(".header-style-3.h-page-12-hdr .logo-header .logo-header-inner img").attr("src", "images/skins-logo/logo-all.png");
        jQuery(".header-style-3.h-page-15-hdr .logo-header .logo-header-inner img").attr("src", "images/skins-logo/logo-white.png");
        return false;
    });
	
    jQuery(".skin-4").on('click', function(){
        jQuery(".skin").attr("href", "css/skins-type/skin-4.css");
		jQuery(".logo-header img").attr("src", "images/skins-logo/logo-skin-4.png");
		jQuery(".footer-dark .logo-footer img").attr("src", "images/skins-logo/logo-skin-4-ftr.png");
		jQuery(".footer-light .logo-footer img").attr("src", "images/skins-logo/logo-skin-4.png");
        jQuery(".page-logo a img").attr("src", "images/skins-logo/logo-skin-4.png");
        jQuery(".twm-log-reg-logo-head a img").attr("src", "images/skins-logo/logo-skin-4.png");
        jQuery(".twm-u-maintenance-content .media a img").attr("src", "images/skins-logo/mainten-logo-4.png");
        jQuery(".header-style-3.h-page-12-hdr .logo-header .logo-header-inner img").attr("src", "images/skins-logo/logo-all.png");
        jQuery(".header-style-3.h-page-15-hdr .logo-header .logo-header-inner img").attr("src", "images/skins-logo/logo-white.png");
        return false;
    });
	
    jQuery(".skin-5").on('click', function(){
        jQuery(".skin").attr("href", "css/skins-type/skin-5.css");
		jQuery(".logo-header img").attr("src", "images/skins-logo/logo-skin-5.png");
		jQuery(".footer-dark .logo-footer img").attr("src", "images/skins-logo/logo-skin-5-ftr.png");
		jQuery(".footer-light .logo-footer img").attr("src", "images/skins-logo/logo-skin-5.png");
        jQuery(".page-logo a img").attr("src", "images/skins-logo/logo-skin-5.png");
        jQuery(".twm-log-reg-logo-head a img").attr("src", "images/skins-logo/logo-skin-5.png");
        jQuery(".twm-u-maintenance-content .media a img").attr("src", "images/skins-logo/mainten-logo-5.png");
        jQuery(".header-style-3.h-page-12-hdr .logo-header .logo-header-inner img").attr("src", "images/skins-logo/logo-all.png");
        jQuery(".header-style-3.h-page-15-hdr .logo-header .logo-header-inner img").attr("src", "images/skins-logo/logo-white.png");
        return false;
    });	

    jQuery(".skin-6").on('click', function(){
        jQuery(".skin").attr("href", "css/skins-type/skin-6.css");
		jQuery(".logo-header img").attr("src", "images/skins-logo/logo-skin-6.png");
		jQuery(".footer-dark .logo-footer img").attr("src", "images/skins-logo/logo-skin-6-ftr.png");
		jQuery(".footer-light .logo-footer img").attr("src", "images/skins-logo/logo-skin-6.png");
        jQuery(".page-logo a img").attr("src", "images/skins-logo/logo-skin-6.png");
        jQuery(".twm-log-reg-logo-head a img").attr("src", "images/skins-logo/logo-skin-6.png");
        jQuery(".twm-u-maintenance-content .media a img").attr("src", "images/skins-logo/mainten-logo-6.png");
        jQuery(".header-style-3.h-page-12-hdr .logo-header .logo-header-inner img").attr("src", "images/skins-logo/logo-all.png");
        jQuery(".header-style-3.h-page-15-hdr .logo-header .logo-header-inner img").attr("src", "images/skins-logo/logo-white.png");
        return false;
    });	

    jQuery(".skin-7").on('click', function(){
        jQuery(".skin").attr("href", "css/skins-type/skin-7.css");
		jQuery(".logo-header img").attr("src", "images/skins-logo/logo-skin-7.png");
		jQuery(".footer-dark .logo-footer img").attr("src", "images/skins-logo/logo-skin-7-ftr.png");
		jQuery(".footer-light .logo-footer img").attr("src", "images/skins-logo/logo-skin-7.png");
        jQuery(".page-logo a img").attr("src", "images/skins-logo/logo-skin-7.png");
        jQuery(".twm-log-reg-logo-head a img").attr("src", "images/skins-logo/logo-skin-7.png");
        jQuery(".twm-u-maintenance-content .media a img").attr("src", "images/skins-logo/mainten-logo-7.png");
        jQuery(".header-style-3.h-page-12-hdr .logo-header .logo-header-inner img").attr("src", "images/skins-logo/logo-all.png");
        jQuery(".header-style-3.h-page-15-hdr .logo-header .logo-header-inner img").attr("src", "images/skins-logo/logo-white.png");
        return false;
    });

    jQuery(".skin-8").on('click', function(){
        jQuery(".skin").attr("href", "css/skins-type/skin-8.css");
		jQuery(".logo-header img").attr("src", "images/skins-logo/logo-skin-8.png");
		jQuery(".footer-dark .logo-footer img").attr("src", "images/skins-logo/logo-skin-8-ftr.png");
		jQuery(".footer-light .logo-footer img").attr("src", "images/skins-logo/logo-skin-8.png");
        jQuery(".page-logo a img").attr("src", "images/skins-logo/logo-skin-8.png");
        jQuery(".twm-log-reg-logo-head a img").attr("src", "images/skins-logo/logo-skin-8.png");
        jQuery(".twm-u-maintenance-content .media a img").attr("src", "images/skins-logo/mainten-logo-8.png");
        jQuery(".header-style-3.h-page-12-hdr .logo-header .logo-header-inner img").attr("src", "images/skins-logo/logo-all.png");
        jQuery(".header-style-3.h-page-15-hdr .logo-header .logo-header-inner img").attr("src", "images/skins-logo/logo-white.png");
        return false;
    });

    jQuery(".skin-9").on('click', function(){
        jQuery(".skin").attr("href", "css/skins-type/skin-9.css");
		jQuery(".logo-header img").attr("src", "images/skins-logo/logo-skin-9.png");
		jQuery(".footer-dark .logo-footer img").attr("src", "images/skins-logo/logo-skin-9-ftr.png");
		jQuery(".footer-light .logo-footer img").attr("src", "images/skins-logo/logo-skin-9.png");
        jQuery(".page-logo a img").attr("src", "images/skins-logo/logo-skin-9.png");
        jQuery(".twm-log-reg-logo-head a img").attr("src", "images/skins-logo/logo-skin-9.png");
        jQuery(".twm-u-maintenance-content .media a img").attr("src", "images/skins-logo/mainten-logo-9.png");
        jQuery(".header-style-3.h-page-12-hdr .logo-header .logo-header-inner img").attr("src", "images/skins-logo/logo-all.png");
        jQuery(".header-style-3.h-page-15-hdr .logo-header .logo-header-inner img").attr("src", "images/skins-logo/logo-white.png");
        return false;
    });

    jQuery(".skin-10").on('click', function(){
        jQuery(".skin").attr("href", "css/skins-type/skin-10.css");
		jQuery(".logo-header img").attr("src", "images/skins-logo/logo-skin-10.png");
		jQuery(".footer-dark .logo-footer img").attr("src", "images/skins-logo/logo-skin-10-ftr.png");
		jQuery(".footer-light .logo-footer img").attr("src", "images/skins-logo/logo-skin-10.png");
        jQuery(".page-logo a img").attr("src", "images/skins-logo/logo-skin-10.png");
        jQuery(".twm-log-reg-logo-head a img").attr("src", "images/skins-logo/logo-skin-10.png");
        jQuery(".twm-u-maintenance-content .media a img").attr("src", "images/skins-logo/mainten-logo-10.png");
        jQuery(".header-style-3.h-page-12-hdr .logo-header .logo-header-inner img").attr("src", "images/skins-logo/logo-all.png");
        jQuery(".header-style-3.h-page-15-hdr .logo-header .logo-header-inner img").attr("src", "images/skins-logo/logo-white.png");
        return false;
    });	


		
});


